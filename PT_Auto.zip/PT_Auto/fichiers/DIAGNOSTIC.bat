@echo off
chcp 65001 >nul
cd /d "%~dp0"
python pt_auto.py --diagnostic
echo.
pause
