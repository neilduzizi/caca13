@echo off
rem Ramene a l ecran la fenetre "Packet Tracer MCP" (depannage uniquement).
cd /d "%~dp0"
python pt_auto.py --montrer-pont
timeout /t 3 >nul
