# -*- coding: utf-8 -*-
"""
pt_ui - Pilotage de l'interface de Cisco Packet Tracer sous Windows.

Utilisé par :
  - pt_setup.py : enregistre le module de script cisco-pt-mcp.pts et vérifie la chaîne complète ;
  - pt_auto.py  : ouvre automatiquement la fenêtre « Packet Tracer MCP » et affiche les messages
                  quand le script tourne en arrière-plan (sans terminal).

Les menus de Packet Tracer sont atteints par l'accessibilité Windows (UI Automation, via
pywinauto). Si ce mécanisme échoue sur une machine, chaque fonction renvoie False au lieu de
lever une exception : l'appelant passe alors à une solution guidée.
"""
from __future__ import annotations

import ctypes
import glob
import os
import platform
import re
import subprocess
import time
from pathlib import Path

IS_WINDOWS = platform.system() == "Windows"

try:  # facultatif : sans pywinauto, les fonctions de menu renvoient False
    from pywinauto import Application
    from pywinauto.keyboard import send_keys
except Exception:
    Application = send_keys = None

try:
    import pyperclip
except Exception:
    pyperclip = None

MAIN_TITLE = "cisco packet tracer"
MCP_MENU = "Packet Tracer MCP"          # libellé ajouté au menu Extensions par cisco-pt-mcp.pts
MCP_WINDOW = "Packet Tracer MCP"        # titre de la fenêtre du pont ouverte par ce menu


# =============================================================================
# Boîtes de message (aucune dépendance)
# =============================================================================
_ICONS = {"info": 0x40, "warning": 0x30, "error": 0x10, "question": 0x20}
_BUTTONS = {"ok": 0x0, "okcancel": 0x1, "yesno": 0x4}
_RESULTS = {1: "ok", 2: "cancel", 6: "yes", 7: "no", 32000: "timeout"}


def message(text: str, title: str = "PT Auto", kind: str = "info",
            buttons: str = "ok", timeout_ms: int = 0) -> str:
    """Affiche une boîte de message au premier plan. Renvoie ok/cancel/yes/no/timeout."""
    if not IS_WINDOWS:
        print(f"[{title}] {text}")
        return "ok"
    from ctypes import wintypes
    user32 = ctypes.windll.user32
    flags = _ICONS.get(kind, 0x40) | _BUTTONS.get(buttons, 0) | 0x40000 | 0x10000  # TOPMOST | SETFOREGROUND
    if timeout_ms:
        try:
            fn = user32.MessageBoxTimeoutW
            fn.argtypes = [wintypes.HWND, wintypes.LPCWSTR, wintypes.LPCWSTR,
                           wintypes.UINT, wintypes.WORD, wintypes.DWORD]
            return _RESULTS.get(fn(None, text, title, flags, 0, timeout_ms), "ok")
        except AttributeError:
            pass
    return _RESULTS.get(user32.MessageBoxW(None, text, title, flags), "ok")


def close_window(title: str) -> None:
    """Ferme une fenêtre (par exemple une boîte de message devenue inutile) par son titre exact."""
    if not IS_WINDOWS:
        return
    user32 = ctypes.windll.user32
    hwnd = user32.FindWindowW(None, title)
    if hwnd:
        user32.PostMessageW(hwnd, 0x0010, 0, 0)        # WM_CLOSE


# =============================================================================
# Fenêtres et processus de Packet Tracer
# =============================================================================
def _proc_path(pid: int) -> str:
    from ctypes import wintypes
    k32 = ctypes.windll.kernel32
    k32.OpenProcess.restype = wintypes.HANDLE
    k32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    k32.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD,
                                               wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
    k32.CloseHandle.argtypes = [wintypes.HANDLE]
    h = k32.OpenProcess(0x1000, False, pid)           # PROCESS_QUERY_LIMITED_INFORMATION
    if not h:
        return ""
    try:
        buf, size = ctypes.create_unicode_buffer(1024), wintypes.DWORD(1024)
        return buf.value if k32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)) else ""
    finally:
        k32.CloseHandle(h)


def list_pt_windows(min_w: int = 1, min_h: int = 1) -> list[dict]:
    """Fenêtres visibles du processus Packet Tracer : hwnd, title, pid, exe, rect."""
    if not IS_WINDOWS:
        return []
    from ctypes import wintypes
    user32 = ctypes.windll.user32
    user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
    user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
    user32.IsWindowVisible.argtypes = [wintypes.HWND]
    user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    paths: dict[int, str] = {}
    wins: list[dict] = []

    def callback(hwnd, _lparam):
        if not user32.IsWindowVisible(hwnd):
            return True
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value not in paths:
            paths[pid.value] = _proc_path(pid.value)
        exe = paths[pid.value]
        if "packettracer" not in os.path.basename(exe).lower():
            return True
        n = user32.GetWindowTextLengthW(hwnd)
        buf = ctypes.create_unicode_buffer(n + 1)
        user32.GetWindowTextW(hwnd, buf, n + 1)
        r = wintypes.RECT()
        user32.GetWindowRect(hwnd, ctypes.byref(r))
        w, h = r.right - r.left, r.bottom - r.top
        if w >= min_w and h >= min_h:
            wins.append({"hwnd": hwnd, "title": buf.value, "pid": pid.value, "exe": exe,
                         "rect": (r.left, r.top, w, h)})
        return True

    proc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)(callback)
    user32.EnumWindows(proc, 0)
    return wins


def main_window() -> dict | None:
    """Fenêtre principale de Packet Tracer (titre « Cisco Packet Tracer ... »), ou None."""
    for w in list_pt_windows(300, 200):
        if w["title"].lower().startswith(MAIN_TITLE):
            return w
    return None


def mcp_window_open() -> bool:
    return any(w["title"].strip().lower() == MCP_WINDOW.lower() for w in list_pt_windows())


def find_pt_exe() -> str:
    """Chemin de PacketTracer.exe : processus en cours, variables PTxHOME, dossiers d'installation."""
    w = main_window()
    if w and w["exe"]:
        return w["exe"]
    cands: list[str] = []
    for key, val in os.environ.items():
        if re.fullmatch(r"PT\d*HOME", key, re.IGNORECASE) and val:
            cands += glob.glob(os.path.join(val, "bin", "PacketTracer*.exe"))
    for root in {os.environ.get("ProgramFiles", r"C:\Program Files"),
                 os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
                 os.environ.get("ProgramW6432", r"C:\Program Files")}:
        cands += glob.glob(os.path.join(root, "Cisco Packet Tracer*", "bin", "PacketTracer*.exe"))

    def version(path: str) -> tuple:
        m = re.search(r"Packet Tracer\s*([\d.]+)", path, re.IGNORECASE)
        return tuple(int(x) for x in m.group(1).strip(".").split(".")) if m else (0,)

    cands = [c for c in dict.fromkeys(cands) if os.path.isfile(c)]
    return max(cands, key=version) if cands else ""


def launch_pt(exe: str) -> None:
    subprocess.Popen([exe], cwd=str(Path(exe).parent), close_fds=True)


def wait_main_window(timeout: float) -> dict | None:
    end = time.time() + timeout
    while time.time() < end:
        w = main_window()
        if w:
            return w
        time.sleep(1)
    return None


def bring_to_front(hwnd) -> None:
    if not IS_WINDOWS:
        return
    user32 = ctypes.windll.user32
    if user32.IsIconic(hwnd):
        user32.ShowWindow(hwnd, 9)                     # SW_RESTORE
    if send_keys:
        try:
            send_keys("{VK_MENU}")                     # contourne le verrou de premier plan
        except Exception:
            pass
    user32.SetForegroundWindow(hwnd)
    time.sleep(0.5)


# =============================================================================
# Menus de Packet Tracer (UI Automation)
# =============================================================================
def _norm(label: str) -> str:
    label = (label or "").split("\t")[0].replace("&", "")
    label = re.sub(r"(\.\.\.|…)\s*$", "", label)
    return re.sub(r"\s+", " ", label).strip().lower()


def _app(pid: int):
    try:                                   # COM doit être initialisé dans le fil appelant
        import comtypes
        comtypes.CoInitialize()
    except Exception:
        pass
    return Application(backend="uia").connect(process=pid, timeout=10)


def _find_menu_item(app, label: str, timeout: float = 5.0):
    """Cherche un élément de menu (barre de menus ou menu déroulant ouvert) par son libellé."""
    target = _norm(label)
    end = time.time() + timeout
    while time.time() < end:
        try:
            for win in app.windows():
                for item in win.descendants(control_type="MenuItem", depth=4):
                    if _norm(item.window_text()) == target:
                        return item
        except Exception:
            pass
        time.sleep(0.3)
    return None


def _escape_menus() -> None:
    try:
        send_keys("{ESC}{ESC}{ESC}")
    except Exception:
        pass


def click_menu(path: list[str]) -> bool:
    """Clique une suite de menus, ex. ["Extensions", "Packet Tracer MCP"]. Renvoie True si réussi."""
    if not (IS_WINDOWS and Application):
        return False
    w = main_window()
    if not w:
        return False
    try:
        app = _app(w["pid"])
        bring_to_front(w["hwnd"])
        for label in path:
            item = _find_menu_item(app, label)
            if item is None:
                _escape_menus()
                return False
            item.click_input()
            time.sleep(0.7)
        return True
    except Exception:
        _escape_menus()
        return False


# =============================================================================
# Fenêtre du pont : invisible mais active
# =============================================================================
# Elle ne peut pas être fermée (c'est elle qui relie Packet Tracer au script) ni simplement
# masquée (SW_HIDE suspendrait la page et Packet Tracer la réafficherait). On la déplace donc
# hors de l'écran et on la retire de la barre des tâches et d'Alt+Tab : elle continue de
# fonctionner, sans être visible ni cliquable.
_OFFSCREEN = -32000
GWL_EXSTYLE, WS_EX_TOOLWINDOW, WS_EX_APPWINDOW = -20, 0x00000080, 0x00040000
SWP_NOSIZE, SWP_NOZORDER, SWP_NOACTIVATE, SWP_FRAMECHANGED = 0x1, 0x4, 0x10, 0x20


def _mcp_hwnds() -> list:
    return [w["hwnd"] for w in list_pt_windows() if w["title"].strip().lower() == MCP_WINDOW.lower()]


def _exstyle(hwnd, add: int = 0, remove: int = 0) -> None:
    """Change le style étendu SANS masquer la fenêtre (masquer/réafficher peut couper la liaison)."""
    user32 = ctypes.windll.user32
    get = getattr(user32, "GetWindowLongPtrW", user32.GetWindowLongW)
    put = getattr(user32, "SetWindowLongPtrW", user32.SetWindowLongW)
    get.restype = put.restype = ctypes.c_ssize_t
    get.argtypes = [ctypes.c_void_p, ctypes.c_int]
    put.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_ssize_t]
    style = get(hwnd, GWL_EXSTYLE)
    new = (style | add) & ~remove
    if new != style:
        put(hwnd, GWL_EXSTYLE, new)


_TASKBAR = None


def _taskbar(hwnd, add: bool) -> None:
    """Retire (ou remet) le bouton de la fenêtre dans la barre des tâches, via ITaskbarList."""
    global _TASKBAR
    try:
        import comtypes
        import comtypes.client
        from comtypes import COMMETHOD, GUID, HRESULT, IUnknown
        from ctypes import wintypes
        comtypes.CoInitialize()
        if _TASKBAR is None:
            class ITaskbarList(IUnknown):
                _iid_ = GUID("{56FDF342-FD6D-11d0-958A-006097C9A090}")
                _methods_ = [
                    COMMETHOD([], HRESULT, "HrInit"),
                    COMMETHOD([], HRESULT, "AddTab", (["in"], wintypes.HWND, "hwnd")),
                    COMMETHOD([], HRESULT, "DeleteTab", (["in"], wintypes.HWND, "hwnd")),
                    COMMETHOD([], HRESULT, "ActivateTab", (["in"], wintypes.HWND, "hwnd")),
                    COMMETHOD([], HRESULT, "SetActiveAlt", (["in"], wintypes.HWND, "hwnd")),
                ]
            tb = comtypes.client.CreateObject(GUID("{56FDF344-FD6D-11d0-958A-006097C9A090}"),
                                              interface=ITaskbarList)
            tb.HrInit()
            _TASKBAR = tb
        (_TASKBAR.AddTab if add else _TASKBAR.DeleteTab)(hwnd)
    except Exception:
        pass                                           # sans conséquence : seule l'icône reste


def hide_mcp_window() -> bool:
    """Rend la fenêtre du pont invisible : hors écran, sans bouton dans la barre des tâches,
    absente d'Alt+Tab. Elle n'est jamais masquée ni fermée, donc la liaison n'est pas coupée."""
    if not IS_WINDOWS:
        return False
    user32 = ctypes.windll.user32
    hwnds = _mcp_hwnds()
    for hwnd in hwnds:
        try:
            user32.SetWindowPos(hwnd, None, _OFFSCREEN, _OFFSCREEN, 0, 0,
                                SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE)
            _exstyle(hwnd, add=WS_EX_TOOLWINDOW, remove=WS_EX_APPWINDOW)
            _taskbar(hwnd, add=False)
        except Exception:
            pass
    main = main_window()
    if hwnds and main:                                # le focus revient à Packet Tracer
        user32.SetForegroundWindow(main["hwnd"])
    return bool(hwnds)


def show_mcp_window() -> bool:
    """Ramène la fenêtre du pont à l'écran (dépannage : MONTRER_PONT.bat)."""
    if not IS_WINDOWS:
        return False
    user32 = ctypes.windll.user32
    hwnds = _mcp_hwnds()
    for hwnd in hwnds:
        try:
            _exstyle(hwnd, remove=WS_EX_TOOLWINDOW)
            _taskbar(hwnd, add=True)
            user32.SetWindowPos(hwnd, None, 120, 120, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED)
            user32.SetForegroundWindow(hwnd)
        except Exception:
            pass
    return bool(hwnds)


def kill_stale_runs() -> int:
    """Arrête les résolutions PT Auto restées bloquées en arrière-plan (invisibles, car lancées
    sans terminal) : elles occupent la liaison et empêchent tout nouveau lancement."""
    if not IS_WINDOWS:
        return 0
    ps = ("$n=0; Get-CimInstance Win32_Process -Filter \"Name LIKE 'python%'\" | "
          f"Where-Object {{ ($_.CommandLine -like '*pt_auto.py*' -or $_.CommandLine -like '*pt_pas_a_pas.py*') "
          f"-and $_.ProcessId -ne {os.getpid()} }} | "
          "ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue; $n++ }; $n")
    try:
        import base64                                  # commande encodée : aucun souci de guillemets
        enc = base64.b64encode(ps.encode("utf-16-le")).decode("ascii")
        out = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-EncodedCommand", enc],
                             capture_output=True, text=True, timeout=30,
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)).stdout
        time.sleep(1)
        return int((out or "0").strip().splitlines()[-1])
    except Exception:
        return 0


def open_mcp_window(timeout: float = 8.0, hidden: bool = True) -> bool:
    """Ouvre Extensions > Packet Tracer MCP si besoin, puis rend la fenêtre invisible.

    Une fois cachée, elle reste ouverte jusqu'à la fermeture de Packet Tracer et se reconnecte
    seule à chaque lancement du script : le menu n'est donc utilisé qu'une fois par session."""
    if mcp_window_open():
        if hidden:
            hide_mcp_window()
        return True
    if not click_menu(["Extensions", MCP_MENU]):
        return False
    end = time.time() + timeout
    while time.time() < end:
        if mcp_window_open():
            if hidden:
                hide_mcp_window()                     # dès son apparition : à peine visible
            return True
        time.sleep(0.05)
    return False


def _new_windows(before: set, pid: int, timeout: float) -> list[dict]:
    end = time.time() + timeout
    while time.time() < end:
        new = [w for w in list_pt_windows() if w["hwnd"] not in before and w["pid"] == pid]
        if new:
            return new
        time.sleep(0.4)
    return []


# =============================================================================
# Enregistrement du module (Extensions > Scripting > Configure PT Script Modules)
# =============================================================================
MODULES_TITLE = "configure pt script modules"
MODULE_NAMES = ("cisco-pt-mcp", "com.bscgi.cisco-pt-mcp")
LAST_ERROR = ""                       # cause du dernier échec, affichée par pt_setup
DUMP_FILE = Path(__file__).resolve().parent / "pt_setup_interface.txt"

# Position des boutons dans la fenêtre « Configure PT Script Modules » (proportions mesurées sur
# la capture fournie : fenêtre de 925 x 525). Dernier recours si l'accessibilité ne les expose pas.
_REL = {"add": (0.305, 0.730), "start": (0.110, 0.731), "ok": (0.942, 0.962)}
_POSITIVE = ("yes", "oui", "ok", "allow", "autoriser", "accept", "accepter", "continue", "continuer",
             "open", "ouvrir", "add", "ajouter", "trust", "approuver")


def _fail(msg: str) -> bool:
    global LAST_ERROR
    LAST_ERROR = msg
    return False


def _wait_window(pred, timeout: float, exclude: set | None = None) -> dict | None:
    """Attend une fenêtre de Packet Tracer qui satisfait pred(fenêtre)."""
    end = time.time() + timeout
    while time.time() < end:
        for w in list_pt_windows():
            if (not exclude or w["hwnd"] not in exclude) and pred(w):
                return w
        time.sleep(0.25)
    return None


def _controls(win) -> list:
    try:
        return win.descendants()
    except Exception:
        return []


def _ctrl_type(c) -> str:
    try:
        return c.element_info.control_type or ""
    except Exception:
        return ""


def _find(win, names: tuple, types: tuple = ("Button",)):
    for c in _controls(win):
        try:
            if _ctrl_type(c) in types and _norm(c.window_text()) in names:
                return c
        except Exception:
            continue
    return None


def _press(ctrl) -> bool:
    """Active un bouton : motif Invoke (sans souris), sinon vrai clic au centre."""
    for how in ("invoke", "click_input"):
        try:
            getattr(ctrl, how)()
            return True
        except Exception:
            continue
    return False


def _click_rel(hwnd, key: str) -> None:
    from ctypes import wintypes
    r = wintypes.RECT()
    ctypes.windll.user32.GetWindowRect(hwnd, ctypes.byref(r))
    rx, ry = _REL[key]
    x, y = int(r.left + rx * (r.right - r.left)), int(r.top + ry * (r.bottom - r.top))
    ctypes.windll.user32.SetForegroundWindow(hwnd)
    time.sleep(0.3)
    try:
        import pyautogui
        pyautogui.click(x, y)
    except Exception:
        ctypes.windll.user32.SetCursorPos(x, y)
        ctypes.windll.user32.mouse_event(0x2, 0, 0, 0, 0)
        ctypes.windll.user32.mouse_event(0x4, 0, 0, 0, 0)


def _module_listed(win) -> bool:
    for c in _controls(win):
        try:
            if _norm(c.window_text()) in MODULE_NAMES:
                return True
        except Exception:
            continue
    return False


def _dump(win, label: str) -> None:
    """Enregistre la structure de la fenêtre (pour diagnostic à distance)."""
    try:
        lines = [f"===== {label} : {win.window_text()!r} ====="]
        for c in _controls(win):
            try:
                r = c.rectangle()
                lines.append(f"{_ctrl_type(c):<14} {c.window_text()!r:<45} "
                             f"({r.left},{r.top},{r.right},{r.bottom}) enabled={c.is_enabled()}")
            except Exception:
                continue
        with open(DUMP_FILE, "a", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n\n")
    except Exception:
        pass


def _confirm_popups(pid: int, keep: set, timeout: float = 4.0) -> None:
    """Valide les éventuelles boîtes de confirmation apparues (autorisations du module, etc.)."""
    end = time.time() + timeout
    while time.time() < end:
        for w in list_pt_windows():
            if w["hwnd"] in keep or w["pid"] != pid or w["title"].lower().startswith(MAIN_TITLE):
                continue
            try:
                popup = _app(pid).window(handle=w["hwnd"])
                btn = _find(popup, _POSITIVE)
                if btn is not None:
                    _press(btn)
                    keep.add(w["hwnd"])
                    time.sleep(0.6)
            except Exception:
                pass
        time.sleep(0.4)


def _choose_file(pid: int, before: set, pts_path: str) -> bool:
    """Remplit la boîte « Ouvrir » avec le chemin du .pts et la valide."""
    dlg_info = _wait_window(lambda w: w["pid"] == pid and w["rect"][2] > 300 and w["rect"][3] > 200,
                            10, exclude=before)
    if not dlg_info:
        return _fail("la boîte de choix du fichier ne s'est pas ouverte après le clic sur Add")
    time.sleep(0.8)
    dlg = _app(pid).window(handle=dlg_info["hwnd"])
    filled = False
    edits = []
    for c in _controls(dlg):                          # zone « Nom du fichier »
        try:
            if _ctrl_type(c) == "Edit" and c.is_enabled():
                aid = (c.element_info.automation_id or "").lower()
                name = _norm(c.element_info.name or "")
                score = (3 if aid == "1148" else 2 if "filename" in aid
                         else 1 if ("nom du fichier" in name or "file name" in name) else 0)
                if score:
                    edits.append((score, c))
        except Exception:
            continue
    for _, c in sorted(edits, key=lambda e: -e[0]):   # Windows : id 1148 ; Qt : fileNameEdit
        try:
            c.set_edit_text(str(pts_path))
            filled = True
            break
        except Exception:
            continue
    if not filled:                                    # repli : collage (insensible à l'AZERTY)
        ctypes.windll.user32.SetForegroundWindow(dlg_info["hwnd"])
        time.sleep(0.3)
        pyperclip.copy(str(pts_path))
        send_keys("^a^v")
    time.sleep(0.4)
    btn = _find(dlg, ("ouvrir", "open", "add", "ajouter", "ok", "select", "sélectionner"))
    if btn is None or not _press(btn):
        send_keys("{ENTER}")
    return True


def register_script_module(pts_path: str) -> bool:
    """Extensions > Scripting > Configure PT Script Modules > Add > fichier .pts > Ok.

    Si cisco-pt-mcp figure déjà dans la liste, il n'est pas rajouté : il est seulement démarré.
    En cas d'échec, la cause est dans LAST_ERROR et la structure des fenêtres dans DUMP_FILE."""
    global LAST_ERROR
    LAST_ERROR = ""
    if not (IS_WINDOWS and Application and pyperclip):
        return _fail("pywinauto ou pyperclip n'est pas installé")
    w = main_window()
    if not w:
        return _fail("Packet Tracer n'est pas ouvert")
    pid = w["pid"]
    try:
        DUMP_FILE.unlink()
    except Exception:
        pass
    try:
        # 1. Ouvrir la fenêtre des modules (reconnue par son titre, pas par « nouvelle fenêtre » :
        #    les menus déroulants de Packet Tracer sont eux aussi des fenêtres)
        mod = _wait_window(lambda x: x["title"].strip().lower() == MODULES_TITLE, 0.5)
        if not mod:
            if not click_menu(["Extensions", "Scripting", "Configure PT Script Modules"]):
                return _fail("menu Extensions > Scripting > Configure PT Script Modules introuvable")
            mod = _wait_window(lambda x: x["title"].strip().lower() == MODULES_TITLE, 10)
        if not mod:
            return _fail("la fenêtre « Configure PT Script Modules » ne s'est pas ouverte")
        time.sleep(0.8)
        app = _app(pid)
        dlg = app.window(handle=mod["hwnd"])
        _dump(dlg, "Configure PT Script Modules")

        # 2. Ajouter le module s'il n'est pas déjà dans la liste
        if not _module_listed(dlg):
            before = {x["hwnd"] for x in list_pt_windows()}
            add = _find(dlg, ("add", "ajouter", "add..."))
            if add is None or not _press(add):
                _click_rel(mod["hwnd"], "add")        # dernier recours : position du bouton
            if not _choose_file(pid, before, pts_path):
                _dump(dlg, "après Add")
                return False
            _confirm_popups(pid, before | {mod["hwnd"]})
            end = time.time() + 8
            while time.time() < end and not _module_listed(dlg):
                time.sleep(0.5)
            if not _module_listed(dlg):
                _dump(dlg, "après ajout")
                return _fail("le fichier a été choisi mais cisco-pt-mcp n'apparaît pas dans la liste")

        # 3. Le sélectionner et le démarrer s'il est arrêté
        for c in _controls(dlg):
            try:
                if _norm(c.window_text()) in MODULE_NAMES:
                    try:
                        c.select()
                    except Exception:
                        c.click_input()
                    break
            except Exception:
                continue
        time.sleep(0.5)
        start = _find(dlg, ("start", "démarrer"))
        if start is not None and start.is_enabled():
            keep = {x["hwnd"] for x in list_pt_windows()}
            _press(start)
            _confirm_popups(pid, keep, 3)

        # 4. Fermer avec Ok
        ok = _find(dlg, ("ok", "close", "fermer"))
        if ok is None or not _press(ok):
            _click_rel(mod["hwnd"], "ok")
        time.sleep(1)
        return True
    except Exception as e:
        _escape_menus()
        return _fail(f"erreur inattendue : {e}")
