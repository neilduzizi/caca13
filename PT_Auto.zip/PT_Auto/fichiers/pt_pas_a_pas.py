#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PT Auto - mode PAS À PAS : vous gardez la main sur le rythme.

1. Comme le mode rapide : lecture des consignes, analyse COMPLÈTE du TP par Gemini.
2. Gemini prépare la séquence chronologique de TOUTES les commandes, chacune avec une
   courte explication. Rien n'est exécuté à ce stade.
3. Chaque CLIC MOLETTE exécute UNE seule étape, puis le script attend le clic suivant :
     - commandes IOS : réellement TAPÉES dans l'onglet CLI de l'équipement (visibles dans
       son historique, exactement comme si vous les tapiez) ;
     - équipements, modules, câbles, adresses IP des PC : appliqués par l'extension.
4. Un petit panneau (coin inférieur droit, non cliquable) affiche l'étape suivante,
   son explication et le résultat de la précédente.

Commandes pendant la séance :
  Clic molette   exécuter l'étape affichée (en cas d'échec : la réessayer)
  Ctrl+F9        passer l'étape affichée
  Ctrl+F12       arrêter

Usage :
  pythonw pt_pas_a_pas.py                 # raccourci « TP pas à pas Packet Tracer »
  python  pt_pas_a_pas.py consignes.pdf   # consignes depuis un fichier
  python  pt_pas_a_pas.py --reprendre     # reprendre la dernière séance là où elle s'est arrêtée
"""
from __future__ import annotations

import argparse
import asyncio
import ctypes
import json
import logging
import queue
import re
import sys
import threading
import time
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import pt_auto as core          # moteur commun : pont, Gemini, lecture des consignes  # noqa: E402

try:
    import pt_ui                # fenêtres et accessibilité de Packet Tracer (Windows)
except Exception:
    pt_ui = None
try:
    from pynput import keyboard as pkeyboard
    from pynput import mouse as pmouse
except Exception:
    pkeyboard = pmouse = None

IS_WINDOWS = core.IS_WINDOWS
log = logging.getLogger("pt_auto")
core.LOG_FILE = HERE / "pt_pas_a_pas.log"

STEP_CONFIG = {
    "delai_frappe": 0.03,       # secondes entre deux caractères tapés (frappe visible)
    "pause_commande": 0.6,      # attente après Entrée, le temps que l'IOS réponde
    "attente_fenetre": 5.0,     # attente de l'ouverture de la fenêtre d'un équipement
}


# =============================================================================
# CONSIGNES SUPPLÉMENTAIRES POUR GEMINI (mode pas à pas)
# =============================================================================
STEP_PROMPT = core.SYSTEM_PROMPT + """
MODE PAS À PAS (prioritaire sur la règle 5) : laisse "ios_configs" VIDE ({}). Produis à la place
"sequence" : la liste CHRONOLOGIQUE de TOUTES les commandes, dans l'ordre exact des étapes du TP,
telles qu'un étudiant les taperait lui-même dans la CLI, chacune avec son explication :
  "sequence": [
    {"device": "S1", "command": "enable", "explication": "Passe en mode privilégié pour pouvoir configurer."},
    {"device": "S1", "command": "configure terminal", "explication": "Entre en configuration globale."},
    {"device": "S1", "command": "interface GigabitEthernet0/1", "explication": "Sélectionne le lien vers S2."},
    {"device": "PC0", "type": "pc", "explication": "Adresse IP de PC0 selon la table d'adressage."}
  ],
  "acces": {"R1": {"enable": "class", "console": "cisco"}}

Règles de la séquence :
a. Une commande par élément, écrite en entier (pas d'abréviation : "configure terminal", "interface GigabitEthernet0/1").
b. Chaque bloc consécutif de commandes sur un même équipement part du mode privilégié (#) et y revient :
   la 1re fois sur un équipement commence par "enable" ; mets "configure terminal" avant toute commande de
   configuration ; termine le bloc par "end". En revenant plus tard sur cet équipement, recommence par "configure terminal".
c. Respecte l'ordre du TP, y compris les allers-retours entre équipements (ex. S1, puis S2, puis de nouveau S1).
d. Mets les "exit" pour quitter les sous-modes, et "no shutdown" sur chaque interface utilisée.
e. N'inclus PAS : la sauvegarde (ajoutée automatiquement à la fin), show, ping, traceroute, reload, debug.
f. "explication" : une phrase courte en français qui dit ce que fait la commande et POURQUOI, de façon pédagogique.
g. PC/serveurs : un élément {"device": "PC0", "type": "pc", "explication": "..."} à l'endroit où le TP le demande ;
   les valeurs IP restent dans "hosts".
h. "acces" (facultatif) : mots de passe DÉJÀ présents sur les équipements AVANT le TP (donnés par les consignes),
   pour se connecter à la console ou passer "enable". Ne mets pas ceux que la séquence va configurer.
"""


# =============================================================================
# PRÉPARATION DES ÉTAPES
# =============================================================================
ENABLE_RE = re.compile(r"^en(a(b(le?)?)?)?$", re.I)
CONF_T_RE = re.compile(r"^conf(ig(ure)?)?(\s+t(erm(inal)?)?)?$", re.I)
SAVE_RE = re.compile(r"^(wr(ite)?(\s+mem(ory)?)?|copy\s+run\S*\s+start\S*)$", re.I)
DROP_RE = re.compile(r"^(do\s+)?(show|sh|ping|traceroute|tracert|reload|debug|undebug|terminal\s+length)\b", re.I)
EXEC_RE = re.compile(r"^(en|ena|enab|enabl|enable|conf|config|configure|end|exit|disable|write|wr|copy|show|"
                     r"sh|do|clock\s+set|terminal|debug|undebug|ping|traceroute|telnet|ssh|clear)\b", re.I)
SUBMODE_RE = re.compile(r"^(interface|int|router\s|line\s|ip\s+dhcp\s+pool|ip\s+access-list|ipv6\s+access-list|"
                        r"ipv6\s+router|class-map|policy-map|key\s+chain|crypto\s+isakmp\s+policy|crypto\s+map|"
                        r"spanning-tree\s+mst\s+configuration|vlan\s+\d|controller|dial-peer|telephony-service|"
                        r"ephone|zone\s+security|archive|ip\s+sla\s+\d|track\s+\d|redundancy|object-group)", re.I)
NESTED_RE = re.compile(r"^(address-family|class\s+\S)", re.I)
TYPE_FR = {"router": "routeur", "switch": "switch", "multilayerswitch": "switch multicouche",
           "pc": "PC", "server": "serveur", "laptop": "portable", "printer": "imprimante"}


def next_ctx(depth: int, ctx: list[str], cmd: str) -> list[str]:
    """Commandes qui ont ouvert le(s) sous-mode(s) en cours (ex. ["interface GigabitEthernet0/1"])."""
    new = next_depth(depth, cmd)
    if new <= 1:
        return []
    if new > depth and new >= 2:
        return (ctx[: new - 2] + [cmd.strip()])
    if new == depth and depth >= 2 and (SUBMODE_RE.match(cmd.strip()) or NESTED_RE.match(cmd.strip())):
        return ctx[: depth - 2] + [cmd.strip()]       # ex. interface X puis interface Y
    return ctx[: max(new - 1, 0)]


def next_depth(depth: int, cmd: str) -> int:
    """Profondeur de mode IOS après la commande : 0 = privilégié (#), 1 = config, 2+ = sous-mode."""
    c = cmd.strip()
    low = c.lower()
    if CONF_T_RE.match(c):
        return 1
    if low == "end":
        return 0
    if low == "exit":
        return max(depth - 1, 0)
    if depth >= 2 and NESTED_RE.match(c):
        return 3
    if depth >= 1 and SUBMODE_RE.match(c):
        return 2
    return depth


def _cli(dev: str, cmd: str, expl: str, ajout: bool = False) -> dict:
    return {"kind": "cli", "device": dev, "command": cmd, "explication": expl, "ajout": ajout}


def build_cli_steps(sequence: list[dict], hosts: dict[str, dict]) -> list[dict]:
    """Séquence de Gemini -> étapes sûres : mode privilégié en début de bloc, « end » en fin de bloc,
    jamais de « exit » qui déconnecterait la console, sauvegarde finale de chaque équipement."""
    steps: list[dict] = []
    state: dict[str, dict] = {}
    cur = None
    used_hosts: set[str] = set()

    def add(dev: str, cmd: str, expl: str, ajout: bool = False) -> None:
        st = state[dev]
        step = _cli(dev, cmd, expl, ajout)
        step["depth"], step["ctx"] = st["depth"], list(st["ctx"])   # mode attendu AVANT la commande
        steps.append(step)
        st["ctx"] = next_ctx(st["depth"], st["ctx"], cmd)
        st["depth"] = next_depth(st["depth"], cmd)

    def close(dev: str) -> None:
        if state[dev]["depth"] > 0:
            add(dev, "end", "Retour au mode privilégié (#) avant de passer à un autre équipement.", True)

    for item in sequence:
        dev = str(item.get("device") or "").strip()
        if not dev:
            continue
        expl = str(item.get("explication") or "").strip()
        if item.get("type") == "pc" or (dev in hosts and not item.get("command")):
            if cur:                                        # on quitte proprement l'équipement en cours
                close(cur)
                cur = None
            if dev in hosts and dev not in used_hosts:
                steps.append({"kind": "pc", "device": dev, "host": hosts[dev], "explication": expl})
                used_hosts.add(dev)
            continue
        cmd = re.sub(r"\s+", " ", str(item.get("command") or "")).strip()
        if not cmd or DROP_RE.match(cmd) or SAVE_RE.match(cmd):
            continue
        if cur and cur != dev:
            close(cur)
        cur = dev
        st = state.setdefault(dev, {"depth": 0, "visited": False, "ctx": []})
        if not st["visited"]:
            st["visited"] = True
            if not ENABLE_RE.match(cmd):
                add(dev, "enable", "Passage en mode privilégié (#), indispensable pour configurer.", True)
        if ENABLE_RE.match(cmd):
            if st["depth"] == 0 and steps and steps[-1].get("device") == dev and steps[-1].get("command") == "enable":
                continue                                   # déjà ajouté juste avant
            if st["depth"] > 0:
                continue                                   # inutile en mode configuration
        elif CONF_T_RE.match(cmd):
            if st["depth"] == 1:
                continue                                   # déjà en configuration globale
            if st["depth"] > 1:
                add(dev, "end", "Retour au mode privilégié.", True)
        elif cmd.lower() == "exit" and st["depth"] == 0:
            continue                                       # fermerait la session console
        elif cmd.lower() == "end" and st["depth"] == 0:
            continue
        elif st["depth"] == 0 and not EXEC_RE.match(cmd):
            add(dev, "configure terminal", "Entrée en mode de configuration globale.", True)
        add(dev, cmd, expl)
    if cur:
        close(cur)
    for name, h in hosts.items():                          # PC oubliés par la séquence
        if name not in used_hosts:
            steps.append({"kind": "pc", "device": name, "host": h,
                          "explication": f"Adressage IP de {name} selon la table d'adressage."})
    for dev in state:
        add(dev, "write memory", "Sauvegarde : la configuration active devient la configuration de démarrage.", True)
    return steps


def sequence_from_plan(plan: dict) -> list[dict]:
    """Séquence de secours quand Gemini n'en fournit pas : bloc par équipement, puis les PC."""
    seq = []
    for dev, cmds in plan.get("ios_configs", {}).items():
        for c in cmds:
            seq.append({"device": dev, "command": c, "explication": ""})
    for h in plan.get("hosts", []):
        seq.append({"device": h["name"], "type": "pc", "explication": ""})
    return seq


def build_topology_steps(plan: dict, net: dict) -> list[dict]:
    steps = []
    existing = set(net["devices"])
    for d in plan["devices"]:
        if d["name"] in existing:
            continue
        steps.append({"kind": "device", "device": d["name"], "data": d,
                      "explication": f"Ajout du {TYPE_FR.get(d['type'], d['type'])} {d['name']} "
                                     f"(modèle {d['model']}), absent de la maquette."})
    for m in plan["modules"]:
        dev = m["device"]
        have = {p.lower() for p in net["devices"].get(dev, {}).get("ports", [])}
        need = core.ports_needed(plan, dev)
        if have and need and all(x.lower() in have for x in need):
            continue
        steps.append({"kind": "module", "device": dev, "data": m,
                      "explication": f"Installation de la carte {m['model']} dans le slot {m['slot']} de {dev} "
                                     "(ajoute les ports nécessaires, par ex. les ports série)."})
    pairs = [tuple(sorted((a.lower(), b.lower()))) for a, b in net["pairs"]]
    for lk in plan["links"]:
        pair = tuple(sorted((lk["a_port"].lower(), lk["b_port"].lower())))
        if pair in pairs:
            pairs.remove(pair)
            continue
        steps.append({"kind": "link", "device": lk["a"], "data": lk,
                      "explication": f"Câble {lk['type']} entre {lk['a']} ({lk['a_port']}) et "
                                     f"{lk['b']} ({lk['b_port']})."})
    return steps


def prepare(plan_raw: dict, net: dict) -> tuple[dict, list[dict]]:
    """Plan de Gemini -> (plan normalisé, liste ordonnée des étapes)."""
    sequence = plan_raw.get("sequence") if isinstance(plan_raw.get("sequence"), list) else []
    sequence = [s for s in sequence if isinstance(s, dict)]
    raw = dict(plan_raw)
    if sequence:                                     # ios_configs déduit de la séquence (équipements, ports)
        ios: dict[str, list[str]] = {}
        for s in sequence:
            if s.get("command") and s.get("type") != "pc":
                ios.setdefault(str(s.get("device")), []).append(str(s["command"]).strip())
        raw["ios_configs"] = ios
    plan = core.normalize_plan(raw, net)
    if not sequence:
        sequence = sequence_from_plan(plan)
    hosts = {h["name"]: h for h in plan["hosts"]}
    steps = build_topology_steps(plan, net) + build_cli_steps(sequence, hosts)
    for i, s in enumerate(steps, 1):
        s["n"] = i
    plan["sequence"] = sequence
    return plan, steps


# =============================================================================
# PANNEAU D'INFORMATION (toujours au premier plan, non cliquable, ne prend jamais le focus)
# =============================================================================
class Overlay:
    W = 600

    def __init__(self) -> None:
        self.q: queue.Queue = queue.Queue()
        self.ready = threading.Event()
        self.ok = False

    def start(self) -> None:
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()
        self.ready.wait(8)

    def set(self, **kw) -> None:
        if self.ok:
            self.q.put(("set", kw))

    def hide(self) -> None:
        """Masque le panneau (avant une capture d'écran) et attend que ce soit fait."""
        if self.ok:
            ev = threading.Event()
            self.q.put(("hide", ev))
            ev.wait(2)
            time.sleep(0.15)

    def show(self) -> None:
        if self.ok:
            self.q.put(("show", None))

    def close(self) -> None:
        if self.ok:
            self.q.put(("close", None))
            self.thread.join(3)          # l'interface doit être libérée par SON fil, avant la sortie

    def _run(self) -> None:
        try:
            import tkinter as tk
        except Exception:
            self.ready.set()
            return
        try:
            self._ui(tk)
        finally:
            import gc
            gc.collect()                 # libère les objets Tk dans ce fil (sinon : Tcl_AsyncDelete)

    def _ui(self, tk) -> None:
        try:
            root = tk.Tk()
            root.overrideredirect(True)
            root.attributes("-topmost", True)
            root.attributes("-alpha", 0.94)
            bg, fg, dim = "#10151c", "#eef2f6", "#8a97a6"
            root.configure(bg=bg)
            frame = tk.Frame(root, bg=bg, padx=16, pady=12, highlightthickness=1,
                             highlightbackground="#2f3b4a")
            frame.pack(fill="both", expand=True)
            title = tk.Label(frame, bg=bg, fg=dim, font=("Segoe UI", 9), anchor="w")
            device = tk.Label(frame, bg=bg, fg="#6cb6ff", font=("Segoe UI Semibold", 10), anchor="w")
            cmd = tk.Label(frame, bg=bg, fg=fg, font=("Consolas", 15, "bold"), anchor="w", justify="left",
                           wraplength=self.W - 40)
            expl = tk.Label(frame, bg=bg, fg="#c9d3dd", font=("Segoe UI", 10), anchor="w", justify="left",
                            wraplength=self.W - 40)
            status = tk.Label(frame, bg=bg, fg=dim, font=("Segoe UI", 9), anchor="w", justify="left",
                              wraplength=self.W - 40)
            foot = tk.Label(frame, bg=bg, fg=dim, font=("Segoe UI", 8), anchor="w",
                            text="Clic molette : exécuter    Ctrl+F9 : passer l'étape    Ctrl+F12 : arrêter")
            for wdg, pady in ((title, 0), (device, (6, 0)), (cmd, (2, 4)), (expl, 0), (status, (8, 0)), (foot, (8, 0))):
                wdg.pack(fill="x", pady=pady)
            labels = {"title": title, "device": device, "cmd": cmd, "expl": expl, "status": status}
            colors = {"ok": "#5fd38d", "err": "#ff7b72", "warn": "#f2cc60", "info": dim}
            hwnd = [None]

            def place() -> None:
                root.update_idletasks()
                h = root.winfo_reqheight()
                sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
                root.geometry(f"{self.W}x{h}+{sw - self.W - 24}+{sh - h - 72}")

            def styles() -> None:
                if not IS_WINDOWS:
                    return
                try:
                    hwnd[0] = int(root.wm_frame(), 16)
                    u = ctypes.windll.user32
                    get = getattr(u, "GetWindowLongPtrW", u.GetWindowLongW)
                    put = getattr(u, "SetWindowLongPtrW", u.SetWindowLongW)
                    get.restype = put.restype = ctypes.c_ssize_t
                    get.argtypes = [ctypes.c_void_p, ctypes.c_int]
                    put.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_ssize_t]
                    # TOOLWINDOW | NOACTIVATE | TRANSPARENT (clics traversants) | LAYERED | TOPMOST
                    put(hwnd[0], -20, get(hwnd[0], -20) | 0x80 | 0x08000000 | 0x20 | 0x80000 | 0x8)
                except Exception:
                    pass

            def poll() -> None:
                try:
                    while True:
                        op, arg = self.q.get_nowait()
                        if op == "set":
                            for k, v in arg.items():
                                if k == "status_kind":
                                    status.configure(fg=colors.get(v, dim))
                                elif k in labels:
                                    labels[k].configure(text=v)
                            place()
                        elif op == "hide":
                            if hwnd[0]:
                                ctypes.windll.user32.ShowWindow(hwnd[0], 0)
                            else:
                                root.withdraw()
                            root.update()
                            arg.set()
                        elif op == "show":
                            if hwnd[0]:
                                ctypes.windll.user32.ShowWindow(hwnd[0], 4)   # sans activer
                            else:
                                root.deiconify()
                        elif op == "close":
                            root.destroy()
                            return
                except queue.Empty:
                    pass
                root.after(80, poll)

            title.configure(text="PT Auto · Pas à pas")
            cmd.configure(text="Préparation…")
            place()
            styles()
            self.ok = True
            self.ready.set()
            root.after(80, poll)
            root.mainloop()
        except Exception as e:
            log.warning("Panneau d'information indisponible : %s", e)
            self.ok = False
            self.ready.set()


# =============================================================================
# SAISIE CLAVIER / SOURIS RÉELLE (Windows)
# =============================================================================
if IS_WINDOWS:
    from ctypes import wintypes

    ULONG_PTR = ctypes.c_size_t

    class _KEYBDINPUT(ctypes.Structure):
        _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD),
                    ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

    class _MOUSEINPUT(ctypes.Structure):
        _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD),
                    ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

    class _HARDWAREINPUT(ctypes.Structure):
        _fields_ = [("uMsg", wintypes.DWORD), ("wParamL", wintypes.WORD), ("wParamH", wintypes.WORD)]

    class _INPUTUNION(ctypes.Union):
        _fields_ = [("ki", _KEYBDINPUT), ("mi", _MOUSEINPUT), ("hi", _HARDWAREINPUT)]

    class _INPUT(ctypes.Structure):
        _fields_ = [("type", wintypes.DWORD), ("u", _INPUTUNION)]

    def _send(events: list) -> None:
        arr = (_INPUT * len(events))(*events)
        ctypes.windll.user32.SendInput(len(events), arr, ctypes.sizeof(_INPUT))

    def _key(vk: int = 0, scan: int = 0, flags: int = 0):
        return _INPUT(type=1, u=_INPUTUNION(ki=_KEYBDINPUT(wVk=vk, wScan=scan, dwFlags=flags, time=0, dwExtraInfo=0)))


def type_text(text: str, delay: float) -> None:
    """Tape le texte caractère par caractère (Unicode : indépendant du clavier AZERTY/QWERTY)."""
    for ch in text:
        _send([_key(scan=ord(ch), flags=0x4), _key(scan=ord(ch), flags=0x4 | 0x2)])
        time.sleep(delay)


def press_enter() -> None:
    _send([_key(vk=0x0D), _key(vk=0x0D, flags=0x2)])


def click_at(x: int, y: int) -> None:
    """Clic gauche réel puis retour du pointeur à sa place (l'utilisateur ne perd pas sa souris)."""
    u = ctypes.windll.user32
    pt = wintypes.POINT()
    u.GetCursorPos(ctypes.byref(pt))
    u.SetCursorPos(int(x), int(y))
    time.sleep(0.05)
    u.mouse_event(0x2, 0, 0, 0, 0)
    u.mouse_event(0x4, 0, 0, 0, 0)
    time.sleep(0.12)
    u.SetCursorPos(pt.x, pt.y)


def window_rect(hwnd) -> tuple[int, int, int, int]:
    r = wintypes.RECT()
    ctypes.windll.user32.GetWindowRect(hwnd, ctypes.byref(r))
    return r.left, r.top, r.right, r.bottom


# =============================================================================
# CONSOLE (CLI) DES ÉQUIPEMENTS
# =============================================================================
def prompt_state(text: str | None) -> str:
    if not text:
        return "unknown"
    lines = [ln.rstrip() for ln in text.replace("\r", "").split("\n") if ln.strip()]
    if not lines:
        return "unknown"
    last = lines[-1]
    low = last.lower()
    if re.search(r"\[yes/no\]:?\s*$", low):
        return "setup"
    if "press return to get started" in low:
        return "press_return"
    if "--more--" in low:
        return "more"
    if re.search(r"\[confirm\]\s*$", low) or re.search(r"\[[^\]]*\]\?\s*$", low):
        return "confirm"
    if "how many bits in the modulus" in low:
        return "modulus"
    if re.search(r"password:\s*$", low):
        return "password"
    if re.search(r"\(config\)#\s*$", last):
        return "config"
    if re.search(r"\(config-[^)]*\)#\s*$", last):
        return "subconfig"
    if re.search(r"#\s*$", last):
        return "priv"
    if re.search(r">\s*$", last):
        return "user"
    return "unknown"


IOS_ERROR_RE = re.compile(r"^%\s*(invalid input|incomplete command|ambiguous command|unknown command|"
                          r"unrecognized command|bad mask|.*not a valid)", re.I | re.M)


class Passwords:
    """Mots de passe connus par équipement : fournis par Gemini (« acces ») ou vus dans la séquence."""

    def __init__(self, acces: dict) -> None:
        self.data = {k: dict(v) for k, v in (acces or {}).items() if isinstance(v, dict)}
        self.ctx: dict[str, str] = {}

    def learn(self, dev: str, cmd: str) -> None:
        d = self.data.setdefault(dev, {})
        m = re.match(r"^enable\s+(secret|password)\s+(?:\d\s+)?(\S+)", cmd, re.I)
        if m:
            d["enable"] = m.group(2)
        m = re.match(r"^line\s+(con|console|vty|aux)", cmd, re.I)
        if m:
            self.ctx[dev] = "console" if m.group(1).lower().startswith("con") else m.group(1).lower()
        elif re.match(r"^(interface|router|vlan|end)\b", cmd, re.I):
            self.ctx.pop(dev, None)
        m = re.match(r"^password\s+(?:\d\s+)?(\S+)", cmd, re.I)
        if m and self.ctx.get(dev):
            d[self.ctx[dev]] = m.group(1)

    def get(self, dev: str, kind: str) -> str | None:
        return self.data.get(dev, {}).get(kind)


class CliDriver:
    """Ouvre la fenêtre d'un équipement, affiche son onglet CLI et y tape les commandes."""

    def __init__(self, plan: dict, passwords: Passwords, overlay: Overlay, created: set[str]) -> None:
        self.types = {d["name"]: d["type"] for d in plan["devices"]}
        self.pw = passwords
        self.overlay = overlay
        self.created = created
        self.woken: set[str] = set()
        self.located: dict[str, tuple[int, int]] = {}
        self.vision_tried: set[str] = set()
        self._apps: dict[int, object] = {}

    # ----- fenêtres ---------------------------------------------------------
    def _app(self, pid: int):
        if pid not in self._apps:
            self._apps[pid] = pt_ui._app(pid)
        return self._apps[pid]

    @staticmethod
    def window(name: str) -> dict | None:
        pat = re.compile(rf"^{re.escape(name)}(\s*[-–:|].*)?$")
        for w in pt_ui.list_pt_windows(150, 100):
            if pat.match(w["title"].strip()):
                return w
        return None

    def _wait_window(self, name: str, timeout: float) -> dict | None:
        end = time.time() + timeout
        while time.time() < end:
            w = self.window(name)
            if w:
                return w
            time.sleep(0.25)
        return None

    def locate(self, names: list[str]) -> None:
        """Repère sur l'espace de travail l'icône des équipements (vision de Gemini)."""
        main = pt_ui.main_window()
        if not main or not core.gemini_key() or core.genai is None or core.pyautogui is None:
            return
        left, top, w, h = main["rect"]
        self.overlay.hide()
        try:
            click_at(left + w // 2, top + 12)          # barre de titre : PT au premier plan, sans effet
            time.sleep(0.5)
            img = core.pyautogui.screenshot(region=(left, top, w, h))
        finally:
            self.overlay.show()
        prompt = ("Capture d'écran de Cisco Packet Tracer (espace de travail logique). Pour chaque équipement "
                  "de la liste, trouve son ICÔNE (routeur, switch, PC...) dont l'étiquette de nom, affichée près "
                  "de l'icône, correspond EXACTEMENT au nom. Réponds uniquement en JSON : "
                  '{"NOM": [ymin, xmin, ymax, xmax]} en coordonnées normalisées de 0 à 1000 de l\'icône '
                  "(pas du texte), ou null si tu ne le vois pas. Équipements : " + ", ".join(names))
        try:
            client = core.genai.Client(api_key=core.gemini_key())
            resp = client.models.generate_content(
                model=core.CONFIG["gemini_model"],
                contents=[core.genai_types.Part.from_bytes(data=core.png_bytes(img, 2000), mime_type="image/png"),
                          prompt],
                config=core.genai_types.GenerateContentConfig(
                    response_mime_type="application/json", temperature=0.0,
                    automatic_function_calling=core.genai_types.AutomaticFunctionCallingConfig(disable=True)))
            boxes = core.parse_json_loose(resp.text or "")
        except Exception as e:
            log.warning("Repérage des équipements impossible : %s", e)
            return
        for name, box in boxes.items():
            try:
                y0, x0, y1, x1 = (float(v) for v in box)
                self.located[name] = (int(left + (x0 + x1) / 2000 * w), int(top + (y0 + y1) / 2000 * h))
            except Exception:
                continue
        log.info("Équipements repérés à l'écran : %s", ", ".join(self.located) or "aucun")

    def open_device(self, name: str, all_names: list[str]) -> dict | None:
        w = self.window(name)
        if w:
            return w
        if name not in self.located and name not in self.vision_tried:
            todo = [n for n in all_names if not self.window(n) and n not in self.located]
            self.vision_tried.update(todo or [name])
            self.locate(todo or [name])
        pos = self.located.pop(name, None)
        if pos:
            main = pt_ui.main_window()
            if main:
                click_at(main["rect"][0] + main["rect"][2] // 2, main["rect"][1] + 12)
                time.sleep(0.3)
            click_at(*pos)
            w = self._wait_window(name, STEP_CONFIG["attente_fenetre"])
        return w

    # ----- console ----------------------------------------------------------
    def console(self, w: dict):
        """Affiche l'onglet CLI ; renvoie (contrôle de la console ou None, onglet trouvé ?)."""
        try:
            win = self._app(w["pid"]).window(handle=w["hwnd"])
        except Exception:
            return None, False
        tab_found = False
        for c in pt_ui._controls(win):
            try:
                if pt_ui._ctrl_type(c) == "TabItem" and pt_ui._norm(c.window_text()) == "cli":
                    tab_found = True
                    try:
                        c.select()
                    except Exception:
                        c.click_input()
                    break
            except Exception:
                continue
        time.sleep(0.4)
        best, area = None, 0
        for c in pt_ui._controls(win):
            try:
                if pt_ui._ctrl_type(c) in ("Edit", "Document") and c.is_visible():
                    r = c.rectangle()
                    a = r.width() * r.height()
                    if a > area:
                        best, area = c, a
            except Exception:
                continue
        return best, tab_found

    @staticmethod
    def read(ctrl) -> str | None:
        if ctrl is None:
            return None
        for fn in (lambda: ctrl.get_value(), lambda: ctrl.iface_value.CurrentValue,
                   lambda: ctrl.iface_text.DocumentRange.GetText(-1), lambda: ctrl.window_text()):
            try:
                t = fn()
                if t and len(t) > 3:
                    return str(t)[-4000:]
            except Exception:
                continue
        return None

    @staticmethod
    def focus(w: dict, ctrl) -> None:
        """Clic réel dans la console : met la fenêtre au premier plan et y place le curseur clavier."""
        if ctrl is not None:
            try:
                r = ctrl.rectangle()
                click_at((r.left + r.right) // 2, r.bottom - 14)
                time.sleep(0.2)
                return
            except Exception:
                pass
        left, top, right, bottom = window_rect(w["hwnd"])
        click_at((left + right) // 2, top + int((bottom - top) * 0.55))
        time.sleep(0.2)

    def line(self, text: str, pause: float | None = None) -> None:
        type_text(text, STEP_CONFIG["delai_frappe"])
        press_enter()
        time.sleep(STEP_CONFIG["pause_commande"] if pause is None else pause)

    def handle_prompts(self, dev: str, ctrl, last_cmd: str = "") -> str:
        """Répond aux invites (dialogue initial, RETURN, mots de passe, confirmations). Renvoie l'état final."""
        state = "unknown"
        for _ in range(6):
            state = prompt_state(self.read(ctrl))
            if state == "setup":
                self.line("no", 2.0)
            elif state in ("press_return", "unknown"):
                self.line("", 0.8)
                if state == "unknown":
                    state = prompt_state(self.read(ctrl))
                    if state == "unknown":
                        break
            elif state == "more":
                type_text(" ", 0)
                time.sleep(0.4)
            elif state == "confirm":
                self.line("", 1.0)
            elif state == "modulus":
                self.line("1024", 2.0)
            elif state == "password":
                kind = "enable" if ENABLE_RE.match(last_cmd or "") else "console"
                pwd = self.pw.get(dev, kind) or self.pw.get(dev, "console" if kind == "enable" else "enable")
                if not pwd:
                    return "password"
                self.line(pwd, 0.8)
                last_cmd = ""
            else:
                break
        return state

    def resync(self, dev: str, ctrl, step: dict, state: str) -> bool:
        """Ramène la console dans le mode attendu par l'étape (déconnexion pour inactivité, saisie
        manuelle entre deux clics...). Renvoie False si un mot de passe inconnu bloque."""
        want = step.get("depth")
        cur = {"user": -1, "priv": 0, "config": 1, "subconfig": 2}.get(state)
        if want is None or cur is None:
            return True
        cmd = step["command"]
        if cur == -1 and not ENABLE_RE.match(cmd):
            self.line("enable")
            if self.handle_prompts(dev, ctrl, "enable") == "password":
                return False
            cur = 0
        if cur >= 1 and (want == 0 or (cur >= 2 and want == 1)):
            self.line("end")
            cur = 0
        if want >= 1 and cur == 0:
            self.line("configure terminal")
            cur = 1
        if want >= 2 and cur == 1:
            for c in step.get("ctx", []):
                self.line(c)
        return True

    def run(self, step: dict, all_names: list[str]) -> tuple[str, str]:
        """Exécute une commande CLI. Renvoie (statut, message) ; statut : ok, warn, user, err."""
        dev, cmd = step["device"], step["command"]
        w = self.open_device(dev, all_names)
        if not w:
            return "user", (f"Je n'ai pas trouvé {dev} à l'écran. Cliquez sur {dev} dans Packet Tracer "
                            "pour ouvrir sa fenêtre, puis clic molette.")
        ctrl, tab = self.console(w)
        if not tab and ctrl is None:
            return "user", (f"Onglet CLI de {dev} introuvable : affichez-le (onglet « CLI »), puis clic molette.")
        self.focus(w, ctrl)
        readable = self.read(ctrl) is not None
        if dev not in self.woken or readable:
            if readable:
                state = self.handle_prompts(dev, ctrl)
                if state == "password":
                    return "user", (f"{dev} demande un mot de passe inconnu : tapez-le dans sa CLI, "
                                    "puis clic molette.")
                if not self.resync(dev, ctrl, step, state):
                    return "user", f"{dev} demande le mot de passe enable : tapez-le, puis clic molette."
            else:                                          # console illisible : séquence de réveil sûre
                self.line("", 0.8)
                if self.types.get(dev) == "router" and dev not in self.woken:
                    self.line("no", 2.0)                   # dialogue initial éventuel des routeurs
                    self.line("", 0.8)
            self.woken.add(dev)
        before = self.read(ctrl) or ""
        self.line(cmd)
        self.pw.learn(dev, cmd)
        if not readable:
            return "ok", "commande tapée"
        if self.handle_prompts(dev, ctrl, cmd) == "password":
            return "user", f"{dev} demande un mot de passe inconnu : tapez-le, puis clic molette."
        after = self.read(ctrl) or ""
        new = after[len(before):] if after.startswith(before[:200]) else after[-600:]
        err = IOS_ERROR_RE.search(new)
        if err:
            return "warn", f"l'IOS a répondu : {err.group(0).strip()}"
        return "ok", "commande tapée"


# =============================================================================
# DÉCLENCHEURS : clic molette (intercepté), Ctrl+F9, Ctrl+F12
# =============================================================================
class Triggers:
    def __init__(self, loop: asyncio.AbstractEventLoop, q: asyncio.Queue) -> None:
        self.loop, self.q = loop, q
        self.mouse = self.keys = None
        self.ctrl = False
        self.last = 0.0

    def _emit(self, what: str) -> None:
        self.loop.call_soon_threadsafe(self.q.put_nowait, what)

    def start(self) -> bool:
        if pmouse is None:
            return False

        def mouse_filter(msg, data):
            if msg in (0x0207, 0x0208):                      # bouton du milieu enfoncé / relâché
                injected = bool(data.flags & 0x3)
                if msg == 0x0207 and not injected and time.time() - self.last > 0.25:
                    self.last = time.time()
                    self._emit("next")
                self.mouse.suppress_event()                  # Packet Tracer ne reçoit pas le clic
            return True

        self.mouse = pmouse.Listener(win32_event_filter=mouse_filter)
        self.mouse.start()
        if pkeyboard is not None:
            def on_press(key):
                if key in (pkeyboard.Key.ctrl_l, pkeyboard.Key.ctrl_r, pkeyboard.Key.ctrl):
                    self.ctrl = True
                elif self.ctrl and key == pkeyboard.Key.f9:
                    self._emit("skip")
                elif self.ctrl and key == pkeyboard.Key.f12:
                    self._emit("quit")

            def on_release(key):
                if key in (pkeyboard.Key.ctrl_l, pkeyboard.Key.ctrl_r, pkeyboard.Key.ctrl):
                    self.ctrl = False

            self.keys = pkeyboard.Listener(on_press=on_press, on_release=on_release)
            self.keys.start()
        return True

    def stop(self) -> None:
        for lst in (self.mouse, self.keys):
            try:
                if lst:
                    lst.stop()
            except Exception:
                pass


# =============================================================================
# EXÉCUTION D'UNE ÉTAPE
# =============================================================================
def describe(step: dict) -> tuple[str, str]:
    """(ligne « équipement », ligne « commande ») affichées dans le panneau."""
    k, d = step["kind"], step.get("data", {})
    if k == "cli":
        return f"{step['device']} · CLI" + ("   (ajoutée par sécurité)" if step.get("ajout") else ""), step["command"]
    if k == "pc":
        h = step["host"]
        if h.get("dhcp"):
            return f"{step['device']} · Configuration IP", "DHCP"
        gw = f"   passerelle {h['gateway']}" if h.get("gateway") else ""
        return f"{step['device']} · Configuration IP", f"{h.get('ip', '?')} {h.get('mask', '')}{gw}"
    if k == "device":
        return "Topologie · nouvel équipement", f"{d['name']} ({d['model']})"
    if k == "module":
        return f"{step['device']} · Carte", f"{d['model']} dans le slot {d['slot']}"
    return "Topologie · câble", f"{d['a']} {d['a_port']}  ⟷  {d['b']} {d['b_port']}"


async def run_step(step: dict, bridge, cli: CliDriver | None, all_names: list[str],
                   created: set[str]) -> tuple[str, str]:
    k, d = step["kind"], step.get("data", {})

    async def call(tool: str, **kw) -> dict:
        try:
            return await bridge.call(tool, **kw)
        except Exception as e:
            return {"success": False, "error": str(e)}

    if k == "cli":
        if cli is None:
            return "err", "saisie dans la CLI impossible ici (Windows et pywinauto requis)"
        return cli.run(step, all_names)
    if k == "pc":
        h = step["host"]
        kw = {"deviceName": step["device"], "dhcpEnabled": bool(h.get("dhcp"))}
        if not h.get("dhcp"):
            for src, dst in (("ip", "ipaddress"), ("mask", "subnetMask"),
                             ("gateway", "defaultGateway"), ("dns", "dnsServer")):
                if h.get(src):
                    kw[dst] = str(h[src])
        res = await call("configurePcIp", **kw)
        return ("ok", "adresse appliquée (visible dans Desktop > IP Configuration)") if res.get("success") \
            else ("err", str(res.get("error") or "échec"))
    if k == "device":
        if await core.device_exists(bridge, d["name"]):
            return "ok", "déjà présent"
        res = await call("addDevice", deviceName=d["name"], deviceModel=d["model"], x=int(d["x"]), y=int(d["y"]))
        if res.get("success"):
            created.add(d["name"])
            return "ok", "équipement ajouté"
        return "err", str(res.get("error") or "échec")
    if k == "module":
        dev = d["device"]
        if dev not in created:                    # la carte redémarre l'équipement : on sauvegarde d'abord
            await call("configureIosDevice", deviceName=dev, commands="")
        res = await call("addModule", deviceName=dev, slot=d["slot"], model=d["model"])
        if not res.get("success"):
            nums = re.findall(r"\d+", d["slot"])
            if nums:
                res = await call("addModule", deviceName=dev, slot=int(nums[1] if len(nums) > 1 else nums[0]),
                                 model=d["model"])
        return ("ok", "carte installée") if res.get("success") else ("err", str(res.get("error") or "échec"))
    if k == "link":
        res = await call("addLink", device1Name=d["a"], device1Interface=d["a_port"], device2Name=d["b"],
                         device2Interface=d["b_port"], linkType=d["type"])
        if res.get("success"):
            return "ok", "câble posé"
        return "warn", "refusé par Packet Tracer : câble déjà présent ou port occupé, vérifiez à l'écran"
    return "err", f"étape inconnue : {k}"


# =============================================================================
# SÉANCE
# =============================================================================
def latest_session() -> Path | None:
    runs = sorted(Path(core.CONFIG["runs_dir"]).glob("*/etapes.json"))
    return runs[-1].parent if runs else None


async def session(args) -> int:
    overlay = Overlay()
    overlay.start()
    q: asyncio.Queue = asyncio.Queue()
    loop = asyncio.get_running_loop()
    triggers = Triggers(loop, q)

    resume_dir = None
    if args.reprendre:
        resume_dir = latest_session()
        if not resume_dir:
            raise RuntimeError("Aucune séance précédente à reprendre.")
    run_dir = resume_dir or Path(core.CONFIG["runs_dir"]) / (datetime.now().strftime("%Y%m%d-%H%M%S") + "-pas")
    run_dir.mkdir(parents=True, exist_ok=True)
    journal = run_dir / "pas_a_pas.txt"

    bridge = core.Bridge(core.CONFIG["bridge_host"], core.CONFIG["bridge_port"], core.CONFIG["tool_timeout"])
    try:
        await bridge.start()
    except RuntimeError:
        if pt_ui is None:
            raise
        pt_ui.kill_stale_runs()
        await bridge.start()
    try:
        overlay.set(cmd="Connexion à Packet Tracer…", expl="", status="")
        if not await core.connect_packet_tracer(bridge, core.CONFIG["connect_timeout"]):
            raise RuntimeError("Packet Tracer ne s'est pas connecté (Extensions > Packet Tracer MCP).")
        net, net_err, _ = await core.read_network(bridge)
        if net_err:
            log.warning("Lecture du réseau impossible : %s", net_err)

        # ----- plan et étapes -------------------------------------------------
        if resume_dir:
            saved = json.loads((run_dir / "etapes.json").read_text(encoding="utf-8"))
            plan, steps = saved["plan"], saved["etapes"]
            start = json.loads((run_dir / "progression.json").read_text(encoding="utf-8")).get("suivante", 1) \
                if (run_dir / "progression.json").exists() else 1
            log.info("Reprise de la séance %s à l'étape %d.", run_dir.name, start)
        else:
            if args.plan:
                plan_raw = json.loads(Path(args.plan).read_text(encoding="utf-8"))
            else:
                overlay.set(cmd="Lecture des consignes…", expl="Ne touchez pas à la souris quelques secondes.")
                overlay.hide()
                try:
                    text, pdf, images = await asyncio.to_thread(core.gather_instructions, args.consignes)
                finally:
                    overlay.show()
                (run_dir / "consignes.txt").write_text(text, encoding="utf-8")
                overlay.set(cmd="Analyse du TP par Gemini…",
                            expl="Gemini prépare toutes les commandes et leurs explications (30 à 90 s).")
                plan_raw = await asyncio.to_thread(core.analyze, text, pdf, images, net, net_err, STEP_PROMPT)
            plan, steps = prepare(plan_raw, net)
            start = 1
            (run_dir / "etapes.json").write_text(json.dumps({"plan": plan, "etapes": steps}, indent=2,
                                                            ensure_ascii=False), encoding="utf-8")
        total = len(steps)
        manual = [str(x) for x in plan.get("manuel", []) if str(x).strip()]
        log.info("%d étape(s) préparée(s).", total)
        if not total:
            raise RuntimeError("Aucune étape à exécuter : vérifiez les consignes.")

        created: set[str] = set()
        cli = None
        if IS_WINDOWS and pt_ui is not None and pt_ui.Application is not None:
            cli = CliDriver(plan, Passwords(plan.get("acces", {})), overlay, created)
        all_names = [d["name"] for d in plan["devices"]
                     if d["type"] in ("router", "switch", "multilayerswitch")]

        if not triggers.start():
            raise RuntimeError("Bibliothèque pynput manquante : relancez INSTALLER.bat.")

        # ----- boucle : un clic molette = une étape ---------------------------
        results = {"ok": 0, "warn": 0, "err": 0, "skip": 0}
        last = ("Prêt : %d étapes préparées. Faites un clic molette pour exécuter la première." % total, "info")
        i = start
        while i <= total:
            step = steps[i - 1]
            dev_line, cmd_line = describe(step)
            overlay.set(title=f"PT Auto · Pas à pas      Étape {i} / {total}", device=dev_line, cmd=cmd_line,
                        expl=step.get("explication") or "", status=last[0], status_kind=last[1])
            while not q.empty():                       # clics faits pendant l'exécution précédente : ignorés
                q.get_nowait()
            what = await q.get()
            if what == "quit":
                log.info("Arrêt demandé à l'étape %d.", i)
                break
            if what == "skip":
                results["skip"] += 1
                last = (f"↷ Étape {i} passée : {cmd_line}", "warn")
                with open(journal, "a", encoding="utf-8") as f:
                    f.write(f"[PASSÉE] {i}. {dev_line} : {cmd_line}\n")
                i += 1
            else:
                overlay.set(status=f"Exécution de l'étape {i}…", status_kind="info")
                status, msg = await run_step(step, bridge, cli, all_names, created)
                log.info("Étape %d/%d [%s] %s : %s -> %s", i, total, status.upper(), dev_line, cmd_line, msg)
                with open(journal, "a", encoding="utf-8") as f:
                    f.write(f"[{status.upper()}] {i}. {dev_line} : {cmd_line} -> {msg}\n")
                if status == "user":
                    last = ("➜ " + msg, "warn")          # même étape au prochain clic
                    continue
                if status == "err":
                    results["err"] += 1
                    last = (f"✗ Étape {i} échouée : {msg}. Clic molette pour réessayer, Ctrl+F9 pour passer.",
                            "err")
                    continue
                results[status] += 1
                mark = "✓" if status == "ok" else "⚠"
                last = (f"{mark} Étape {i} : {cmd_line} — {msg}", "ok" if status == "ok" else "warn")
                i += 1
            (run_dir / "progression.json").write_text(json.dumps({"suivante": i}), encoding="utf-8")

        done = i > total
        summary = (f"{'Terminé' if done else 'Arrêté'} : {results['ok']} réussie(s), {results['warn']} avec "
                   f"avertissement, {results['skip']} passée(s).")
        log.info(summary)
        overlay.set(title="PT Auto · Pas à pas", device="", cmd="Terminé" if done else "Arrêté",
                    expl=("Contrôlez le score avec « Check Results »." if done else
                          "Pour continuer plus tard : python pt_pas_a_pas.py --reprendre"),
                    status=summary, status_kind="ok" if done else "warn")
        lines = [summary]
        if manual:
            lines += ["", "À faire à la main :"] + [f"  - {m}" for m in manual]
        if not done:
            lines += ["", "Pour reprendre plus tard là où vous en êtes :", "  python pt_pas_a_pas.py --reprendre"]
        core.popup("\n".join(lines), "info" if done else "warning")
        if not core.HEADLESS and manual:
            for m in manual:
                log.info("À FAIRE À LA MAIN : %s", m)
        await asyncio.sleep(1.5)
        return 0
    finally:
        triggers.stop()
        overlay.close()
        await bridge.stop()


def main() -> None:
    ap = argparse.ArgumentParser(description="PT Auto - résolution pas à pas (un clic molette = une commande)")
    ap.add_argument("consignes", nargs="?", help="fichier de consignes (PDF, TXT, PNG/JPG), facultatif")
    ap.add_argument("--plan", help="utiliser un plan.json déjà produit au lieu d'interroger Gemini")
    ap.add_argument("--reprendre", action="store_true", help="reprendre la dernière séance pas à pas")
    ap.add_argument("--modele", help="modèle Gemini (défaut : gemini-flash-latest)")
    ap.add_argument("--vitesse", type=float, help="secondes entre deux caractères tapés (défaut 0.03)")
    args = ap.parse_args()
    core.setup_logging()
    if args.modele:
        core.CONFIG["gemini_model"] = args.modele
    if args.vitesse is not None:
        STEP_CONFIG["delai_frappe"] = max(0.0, args.vitesse)
    if (HERE / "pont_visible.flag").exists():
        core.CONFIG["masquer_pont"] = False
    if core.socketio is None or core.web is None:
        log.error("Bibliothèques manquantes : relancez INSTALLER.bat")
        sys.exit(2)
    if not args.reprendre:
        core.popup("Mode pas à pas.\n\nLe TP va être lu et analysé (environ 1 minute) : ne touchez pas à la "
                   "souris pendant la lecture des consignes.\n\nEnsuite, chaque clic molette exécute UNE "
                   "commande. Le panneau en bas à droite affiche la suivante et son explication.",
                   "info", timeout_ms=6000)
    try:
        sys.exit(asyncio.run(session(args)))
    except KeyboardInterrupt:
        sys.exit(130)
    except Exception as e:
        if isinstance(e, RuntimeError):
            log.error("%s", e)
        else:
            log.exception("Arrêt")
        core.popup(f"Arrêt : {e}\n\nJournal : {core.LOG_FILE}", "error")
        sys.exit(1)


if __name__ == "__main__":
    main()
