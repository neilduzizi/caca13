#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PT Auto v2 - Résolution automatique d'une activité Cisco Packet Tracer en un lancement.

Aucune calibration, aucun OCR, aucun raccourci clavier :
  1. Le script ouvre un pont local (Socket.IO sur 127.0.0.1:7531) auquel se connecte
     l'extension Packet Tracer « cisco-pt-mcp » (qui utilise l'API IPC de PT).
  2. Il lit l'état réel du réseau : équipements, ports, câbles.
  3. Il récupère les consignes automatiquement :
       - fichier fourni (PDF, TXT, PNG/JPG) en argument ou glissé sur LANCER.bat ;
       - sinon fenêtre d'instructions de Packet Tracer (texte + captures défilées) ;
       - sinon texte présent dans le presse-papiers.
  4. Gemini produit un plan JSON (parseur de secours si Gemini est indisponible).
  5. Le plan est appliqué via le pont, avec un compte rendu par action :
     équipements manquants, modules, câbles, configuration IOS, adressage des PC.

Usage :
  python pt_auto.py                          # tout automatique
  python pt_auto.py consignes.pdf            # consignes depuis un fichier
  python pt_auto.py --apercu                 # analyse seule, rien n'est modifié
  python pt_auto.py --plan runs/<date>/plan.json   # rejouer un plan corrigé
  pythonw pt_auto.py                         # arrière-plan : aucun terminal, messages à l'écran
"""
from __future__ import annotations

import argparse
import asyncio
import ctypes
import io
import json
import logging
import os
import platform
import re
import sys
import time
import uuid
from datetime import datetime
from pathlib import Path

IS_WINDOWS = platform.system() == "Windows"
if IS_WINDOWS:  # coordonnées exactes sur écrans mis à l'échelle (125 %, 150 %...)
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass

# --- Dépendances (imports tolérants, message clair si absentes) ---
try:
    import socketio
    from aiohttp import web
except Exception:
    socketio = web = None
try:
    from google import genai
    from google.genai import types as genai_types
except Exception:
    genai = genai_types = None
try:
    import pyautogui
except Exception:
    pyautogui = None
try:
    import pyperclip
except Exception:
    pyperclip = None
try:
    from PIL import Image, ImageChops, ImageStat
except Exception:
    Image = ImageChops = ImageStat = None

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
try:
    import pt_ui            # menus de Packet Tracer + boîtes de message (Windows)
except Exception:
    pt_ui = None

# Lancé par pythonw.exe (raccourci « Résoudre TP ») : pas de console -> messages à l'écran.
HEADLESS = sys.stdout is None
RUN_WARNINGS: list[str] = []
LOG_FILE = HERE / "pt_auto_dernier.log"


# =============================================================================
# CONFIGURATION
# =============================================================================
CONFIG = {
    "bridge_host": "127.0.0.1",
    "bridge_port": 7531,            # port attendu par l'extension cisco-pt-mcp
    "connect_timeout": 180,         # attente de la connexion de Packet Tracer (s)
    "tool_timeout": 120,            # attente d'une action dans Packet Tracer (s)
    "gemini_model": os.environ.get("PT_GEMINI_MODEL", "gemini-flash-latest"),
    "gemini_max_tokens": 32768,
    "max_images": 12,
    "scroll_notches": 5,
    "max_scroll_steps": 15,
    "runs_dir": str(HERE / "runs"),
    "masquer_pont": True,           # fenêtre « Packet Tracer MCP » invisible (mais active)
}

ROUTER_MODELS = {"1841", "1941", "2811", "2901", "2911", "ISR4321", "ISR4331", "Router-PT"}
SUPPORTED_MODELS = ROUTER_MODELS | {
    "2950-24", "2950T-24", "2960-24TT", "3560-24PS", "3650-24PS", "Switch-PT",
    "PC-PT", "Server-PT", "Laptop-PT", "Printer-PT",
}
DEFAULT_MODELS = {
    "router": "2911", "switch": "2960-24TT", "multilayerswitch": "3560-24PS",
    "pc": "PC-PT", "server": "Server-PT", "laptop": "Laptop-PT", "printer": "Printer-PT",
}
HOST_TYPES = {"pc", "server", "laptop", "printer"}
LINK_TYPES = {"straight", "cross", "serial", "fiber", "console", "auto", "roll", "phone",
              "cable", "wireless", "coaxial", "octal", "cellular", "usb", "custom_io"}

log = logging.getLogger("pt_auto")


def setup_logging() -> None:
    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(message)s", datefmt="%H:%M:%S")
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    try:
        fh = logging.FileHandler(LOG_FILE, mode="w", encoding="utf-8")
        fh.setFormatter(fmt)
        root.addHandler(fh)
    except Exception:
        pass
    if sys.stdout is not None:
        try:
            sys.stdout.reconfigure(encoding="utf-8")
        except Exception:
            pass
        sh = logging.StreamHandler(sys.stdout)
        sh.setFormatter(fmt)
        root.addHandler(sh)
    for noisy in ("aiohttp", "socketio", "engineio", "httpx", "httpcore", "google_genai", "google.genai"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


def popup(text: str, kind: str = "info", buttons: str = "ok", timeout_ms: int = 0) -> str:
    """Boîte de message, seulement quand aucun terminal n'est visible."""
    if not HEADLESS or pt_ui is None:
        return "ok"
    try:
        return pt_ui.message(text, "PT Auto", kind, buttons, timeout_ms)
    except Exception:
        return "ok"


# =============================================================================
# PONT PACKET TRACER (protocole de l'extension cisco-pt-mcp)
#   serveur -> extension : tool_call   {tool_call_id, tool_name, tool_input}
#   extension -> serveur : tool_result {tool_call_id, tool_name, tool_input, result}
# =============================================================================
class Bridge:
    def __init__(self, host: str, port: int, timeout: float):
        self.host, self.port, self.timeout = host, port, timeout
        self.sio = socketio.AsyncServer(async_mode="aiohttp", cors_allowed_origins="*",
                                        logger=False, engineio_logger=False)
        self.app = web.Application()
        self.sio.attach(self.app)
        self.runner = None
        self.sid = None
        self.connected = asyncio.Event()
        self.pending: dict[str, asyncio.Future] = {}
        self.closing = False
        sio = self.sio

        @sio.event
        async def connect(sid, environ, auth=None):
            old, self.sid = self.sid, sid
            self.connected.set()
            log.info("Packet Tracer est connecté au pont.")
            if old and old != sid:
                try:
                    await sio.disconnect(old)
                except Exception:
                    pass

        @sio.event
        async def disconnect(sid, *args):
            if sid == self.sid:
                self.sid = None
                self.connected.clear()
                for fut in self.pending.values():
                    if not fut.done():
                        fut.set_exception(RuntimeError("Packet Tracer s'est déconnecté"))
                self.pending.clear()
                if not self.closing:
                    log.warning("Packet Tracer s'est déconnecté du pont.")

        @sio.on("tool_result")
        async def tool_result(sid, data):
            if not isinstance(data, dict):
                return
            fut = self.pending.pop(str(data.get("tool_call_id")), None)
            if fut and not fut.done():
                fut.set_result(unwrap(data.get("result")))

    async def start(self) -> None:
        try:
            self.runner = web.AppRunner(self.app, access_log=None, shutdown_timeout=2.0)
        except TypeError:       # anciennes versions d'aiohttp
            self.runner = web.AppRunner(self.app, access_log=None)
        await self.runner.setup()
        try:
            await web.TCPSite(self.runner, self.host, self.port).start()
        except OSError as e:
            raise RuntimeError(f"Le port {self.port} est déjà utilisé (un autre programme utilise "
                               f"le pont, ou le script tourne déjà) : {e}")

    async def stop(self) -> None:
        self.closing = True
        for fut in self.pending.values():
            if not fut.done():
                fut.cancel()
        if self.runner:
            try:
                await asyncio.wait_for(self.runner.cleanup(), 2)
            except Exception:
                pass

    async def wait(self, timeout: float) -> bool:
        try:
            await asyncio.wait_for(self.connected.wait(), timeout)
            return True
        except asyncio.TimeoutError:
            return False

    async def call(self, tool: str, **kwargs) -> dict:
        if not self.sid:
            raise RuntimeError("Packet Tracer n'est pas connecté au pont")
        tcid = uuid.uuid4().hex
        fut = asyncio.get_running_loop().create_future()
        self.pending[tcid] = fut
        await self.sio.emit("tool_call", {"tool_call_id": tcid, "tool_name": tool,
                                          "tool_input": kwargs}, to=self.sid)
        try:
            return await asyncio.wait_for(fut, self.timeout)
        except asyncio.TimeoutError:
            self.pending.pop(tcid, None)
            raise RuntimeError(f"{tool} : pas de réponse de Packet Tracer en {self.timeout:.0f} s")


def unwrap(res) -> dict:
    """Retire les enveloppes {code, result, success} que certaines versions de l'extension
    ajoutent : sans cela, un échec réel apparaîtrait comme un succès."""
    for _ in range(5):
        if (isinstance(res, dict) and "code" in res and isinstance(res.get("result"), dict)
                and "success" in res["result"]):
            res = res["result"]
        else:
            break
    return res if isinstance(res, dict) else {"success": False, "error": f"réponse invalide : {res!r}"}


def parse_network(raw) -> dict:
    """Réponse getNetwork -> {"devices": {nom: {"model", "ports": [...]}}, "pairs": [...]}

    Fiable : la liste des équipements, leur modèle et leurs ports (donc les modules présents).
    NON fiable (défaut de l'extension) : à quels équipements appartiennent les câbles existants ;
    seuls les noms de ports des deux extrémités sont exploitables."""
    res = unwrap(raw).get("result", {}) if isinstance(raw, dict) else {}
    if not isinstance(res, dict):
        res = {}
    devices = {}
    for d in res.get("devices", []) or []:
        if not (isinstance(d, dict) and d.get("name")) or not isinstance(d.get("interfaces"), list):
            continue        # ignore les objets techniques (ex. Power Distribution Device)
        ports = [i.get("name") for i in d["interfaces"] if isinstance(i, dict) and i.get("name")]
        devices[d["name"]] = {"model": d.get("model"), "ports": ports}
    pairs = []
    for c in res.get("connections", []) or []:
        if isinstance(c, dict) and c.get("fromInterface") and c.get("toInterface"):
            pairs.append(tuple(sorted((str(c["fromInterface"]), str(c["toInterface"])))))
    return {"devices": devices, "pairs": pairs}


def compress_ports(names: list[str]) -> str:
    """["Fa0/1", "Fa0/2", "Fa0/3"] -> "Fa0/1-3" (réduit fortement la taille envoyée à Gemini)."""
    out, run = [], None              # run = [prefixe, debut, fin]
    for n in names:
        m = re.match(r"^(.*?)(\d+)$", n)
        if m and run and run[0] == m.group(1) and int(m.group(2)) == run[2] + 1:
            run[2] += 1
            continue
        if run:
            out.append(f"{run[0]}{run[1]}" + (f"-{run[2]}" if run[2] != run[1] else ""))
            run = None
        if m:
            run = [m.group(1), int(m.group(2)), int(m.group(2))]
        else:
            out.append(n)
    if run:
        out.append(f"{run[0]}{run[1]}" + (f"-{run[2]}" if run[2] != run[1] else ""))
    return ", ".join(out)


async def read_network(bridge: "Bridge") -> tuple[dict, str, object]:
    """Renvoie (réseau, erreur, réponse brute). erreur == "" si la lecture a réussi."""
    try:
        raw = await bridge.call("getNetwork")
    except Exception as e:
        return parse_network({}), str(e), None
    if not raw.get("success"):
        return parse_network({}), str(raw.get("error") or f"réponse inattendue : {str(raw)[:200]}"), raw
    return parse_network(raw), "", raw


async def device_exists(bridge: "Bridge", name: str) -> bool | None:
    """Sonde sans effet : renommer un équipement avec son propre nom."""
    try:
        res = await bridge.call("renameDevice", deviceName=name, newName=name)
    except Exception:
        return None
    if res.get("success"):
        return True
    return False if "not found" in str(res.get("error", "")).lower() else None


def network_for_llm(net: dict) -> str:
    data = {
        "equipements_existants": [{"nom": n, "modele": d["model"], "ports": compress_ports(d["ports"])}
                                  for n, d in net["devices"].items()],
        "cables_existants": [f"{a} <-> {b}" for a, b in net["pairs"]],
        "remarque": ("Équipements, modèles et ports sont fiables (un port absent = module absent). "
                     "Pour les câbles existants, seuls les noms de ports sont connus, pas les équipements."),
    }
    txt = json.dumps(data, ensure_ascii=False)
    return txt if len(txt) < 60000 else txt[:60000] + "...(tronqué)"


# =============================================================================
# CONSIGNES : fichier, fenêtre d'instructions de Packet Tracer, presse-papiers
# =============================================================================
def list_pt_windows() -> list[dict]:
    """Fenêtres visibles appartenant au processus Packet Tracer (Windows)."""
    if not IS_WINDOWS:
        return []
    from ctypes import wintypes
    user32, kernel32 = ctypes.windll.user32, ctypes.windll.kernel32
    kernel32.OpenProcess.restype = wintypes.HANDLE
    kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel32.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD,
                                                    wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
    user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
    user32.IsWindowVisible.argtypes = [wintypes.HWND]
    user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]

    def proc_path(pid: int) -> str:
        h = kernel32.OpenProcess(0x1000, False, pid)        # PROCESS_QUERY_LIMITED_INFORMATION
        if not h:
            return ""
        try:
            buf, size = ctypes.create_unicode_buffer(1024), wintypes.DWORD(1024)
            return buf.value if kernel32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)) else ""
        finally:
            kernel32.CloseHandle(h)

    wins: list[dict] = []

    def callback(hwnd, _lparam):
        if not user32.IsWindowVisible(hwnd):
            return True
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if "packettracer" not in os.path.basename(proc_path(pid.value)).lower():
            return True
        n = user32.GetWindowTextLengthW(hwnd)
        buf = ctypes.create_unicode_buffer(n + 1)
        user32.GetWindowTextW(hwnd, buf, n + 1)
        r = wintypes.RECT()
        user32.GetWindowRect(hwnd, ctypes.byref(r))
        w, h = r.right - r.left, r.bottom - r.top
        if w >= 300 and h >= 200:
            wins.append({"hwnd": hwnd, "title": buf.value, "rect": (r.left, r.top, w, h)})
        return True

    proc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)(callback)
    user32.EnumWindows(proc, 0)
    return wins


def pick_instruction_window(wins: list[dict]) -> dict | None:
    cands = [w for w in wins
             if not w["title"].lower().startswith("cisco packet tracer") and "mcp" not in w["title"].lower()]
    if not cands:
        return None
    keywords = ("instruction", "activit", "consigne")
    preferred = [w for w in cands if any(k in w["title"].lower() for k in keywords)]
    return max(preferred or cands, key=lambda w: w["rect"][2] * w["rect"][3])


def activate_window(hwnd) -> None:
    user32 = ctypes.windll.user32
    user32.ShowWindow(hwnd, 9)                  # SW_RESTORE
    try:
        pyautogui.press("alt")                  # contourne le verrouillage du premier plan
    except Exception:
        pass
    user32.SetForegroundWindow(hwnd)
    time.sleep(0.7)


def images_same(a, b) -> bool:
    if a.size != b.size:
        return False
    diff = ImageChops.difference(a.convert("L"), b.convert("L"))
    return ImageStat.Stat(diff).mean[0] < 0.8


def capture_instructions_window() -> tuple[str, list]:
    if not (IS_WINDOWS and pyautogui and Image):
        return "", []
    wins = list_pt_windows()
    win = pick_instruction_window(wins)
    if not win:
        if wins:
            log.info("Fenêtres Packet Tracer vues : %s", ", ".join(repr(w["title"]) for w in wins))
        return "", []
    log.info("Fenêtre d'instructions détectée : « %s ». Ne touchez pas à la souris quelques secondes...",
             win["title"])
    activate_window(win["hwnd"])
    left, top, w, h = win["rect"]
    cx, cy = left + w // 2, top + h // 2
    unit = 120                                  # Windows : 120 = un cran de molette

    text = ""
    if pyperclip:
        sentinel = f"__pt_auto_{time.time()}__"
        pyperclip.copy(sentinel)
        pyautogui.click(cx, cy)
        time.sleep(0.3)
        pyautogui.hotkey("ctrl", "a")
        time.sleep(0.2)
        pyautogui.hotkey("ctrl", "c")
        time.sleep(0.5)
        copied = pyperclip.paste() or ""
        pyautogui.click(cx, cy)                 # désélection
        if copied != sentinel:
            text = copied.strip()

    pyautogui.scroll(60 * unit, x=cx, y=cy)     # haut de la page
    time.sleep(0.4)
    shots, prev = [], None
    for _ in range(CONFIG["max_scroll_steps"]):
        img = pyautogui.screenshot(region=(left, top, w, h))
        if prev is not None and images_same(prev, img):
            break
        shots.append(img)
        prev = img
        pyautogui.scroll(-CONFIG["scroll_notches"] * unit, x=cx, y=cy)
        time.sleep(0.4)
    log.info("Consignes capturées : %d caractères de texte, %d capture(s).", len(text), len(shots))
    return text, shots


def gather_instructions(path: str | None) -> tuple[str, bytes | None, list]:
    """Renvoie (texte, pdf_bytes, images)."""
    if path:
        p = Path(path)
        if not p.exists():
            raise RuntimeError(f"Fichier de consignes introuvable : {p}")
        ext = p.suffix.lower()
        log.info("Consignes lues depuis le fichier %s", p.name)
        if ext == ".pdf":
            return "", p.read_bytes(), []
        if ext in (".png", ".jpg", ".jpeg", ".webp", ".bmp"):
            need(Image, "Pillow")
            return "", None, [Image.open(p).copy()]
        return p.read_text(encoding="utf-8", errors="replace"), None, []

    text, images = capture_instructions_window()
    if text or images:
        return text, None, images
    clip = (pyperclip.paste() or "") if pyperclip else ""
    if len(clip.strip()) > 100:
        log.info("Consignes lues depuis le presse-papiers.")
        return clip, None, []
    raise RuntimeError("Consignes introuvables. Ouvrez la fenêtre d'instructions de l'activité, "
                       "ou glissez un fichier PDF/TXT des consignes sur LANCER.bat.")


def need(module, pip_name: str) -> None:
    if module is None:
        raise RuntimeError(f"Bibliothèque manquante : python -m pip install {pip_name}")


# =============================================================================
# ANALYSE : Gemini
# =============================================================================
SYSTEM_PROMPT = """Tu es un ingénieur réseau Cisco expert de Cisco Packet Tracer (niveau CCNA/CCNP).
Tu reçois : (1) l'état ACTUEL du réseau dans Packet Tracer (équipements, ports, câbles existants) ; (2) les consignes d'une activité (texte, PDF et/ou captures d'écran, parfois imparfaits).
Produis le plan COMPLET permettant de réaliser toutes les tâches demandées.

Réponds UNIQUEMENT avec un objet JSON valide :
{
  "devices": [{"name": "R1", "type": "router", "model": "2911", "x": 400, "y": 100}],
  "modules": [{"device": "R1", "slot": "0/0", "model": "HWIC-2T"}],
  "links": [{"a": "R1", "a_port": "GigabitEthernet0/1", "b": "S1", "b_port": "GigabitEthernet0/1", "type": "straight"}],
  "ios_configs": {"R1": ["hostname R1", "interface GigabitEthernet0/1", " ip address 192.168.1.1 255.255.255.0", " no shutdown", " exit"]},
  "hosts": [{"name": "PC-A", "dhcp": false, "ip": "192.168.1.10", "mask": "255.255.255.0", "gateway": "192.168.1.1", "dns": ""}],
  "manuel": ["actions impossibles à automatiser, formulées comme des consignes précises pour l'utilisateur"],
  "notes": ["hypothèses retenues, ambiguïtés"]
}

Règles :
1. Réseau existant : réutilise EXACTEMENT les noms d'équipements et de ports de l'état actuel. Liste dans "devices" tous les équipements de la topologie (existants compris) : seuls les manquants seront ajoutés. La maquette peut être vide, complète, ou à moitié faite (équipements, modules ou câbles manquants) : compare l'état actuel à ce que demandent les consignes.
2. type parmi : router, switch, multilayerswitch, pc, server, laptop, printer. model parmi : 1941, 2901, 2911, ISR4321, 2960-24TT, 3560-24PS, 3650-24PS, PC-PT, Server-PT, Laptop-PT, Printer-PT (garde le modèle des consignes s'il figure dans cette liste). x entre 50 et 1000, y entre 50 et 650, en reproduisant le schéma.
3. links : les câbles que les consignes demandent de poser, avec les ports EXACTS des consignes ou du schéma (les câbles déjà présents seront détectés et ignorés). Si la maquette est déjà câblée et que les consignes ne demandent pas de câbler, laisse links VIDE : ne devine jamais un port. Noms d'interfaces complets (GigabitEthernet0/0, FastEthernet0/1, Serial0/0/0 ; "FastEthernet0" pour un PC/serveur/portable). type parmi straight, cross, serial, fiber, console, auto.
4. modules : toute carte/module à installer, sur un équipement à créer OU déjà existant (ex. consigne « ajoutez une carte HWIC-2T à R1 », ou port requis absent de la liste des ports existants). Sur 1941/2901/2911 : slot "0/0" + "HWIC-2T" donne Serial0/0/0 et Serial0/0/1 ; slot "0/1" pour une deuxième carte. Sur ISR4321 : slot "0/1" + "NIM-2T" donne Serial0/1/0 et Serial0/1/1. N'ajoute pas un module dont les ports existent déjà. Retirer ou remplacer un module, éteindre/rallumer à la main, changer un câble d'équipement physique : non automatisable -> décris l'action précise dans "manuel".
5. ios_configs : par routeur/switch, commandes ordonnées en mode de configuration globale, SANS "enable", "configure terminal", "end" ni sauvegarde (faits automatiquement). Utilise " exit" pour quitter les sous-modes. Couvre TOUTES les tâches : hostname, mots de passe (enable secret, console, vty), service password-encryption, bannière sur une ligne (banner motd #Texte#), VLAN, trunk/access, SVI, ip default-gateway, inter-VLAN, routage statique/OSPF/EIGRP/RIP, DHCP, NAT/PAT, ACL, SSH ("ip domain-name", "username", "crypto key generate rsa general-keys modulus 1024", "ip ssh version 2", "transport input ssh"), port-security, IPv6, etc. Mets "no shutdown" sur chaque interface utilisée. Liaisons série : "clock rate 64000" (ou la valeur demandée) des deux côtés. Aucune commande interactive.
6. hosts : configuration IP de chaque PC/serveur/portable ; dhcp=true si l'adressage doit être dynamique. Les services des serveurs (DHCP, DNS, HTTP, e-mail...), le Wi-Fi et les applications des PC ne sont pas automatisables : décris-les précisément dans "manuel".
7. N'invente rien de contradictoire avec les consignes. Valeur manquante : choix CCNA conventionnel, signalé dans notes.
9. L'activité est NOTÉE AUTOMATIQUEMENT, élément par élément : chaque valeur doit correspondre EXACTEMENT aux consignes (noms d'équipements, hostnames, noms de VLAN avec la même casse et orthographe, mots de passe, domaine VTP, descriptions, numéros de ports, adresses, masques).
10. Applique TOUTES les valeurs de tous les tableaux (adressage, VLAN, affectation des ports), même si elles semblent inutiles : passerelles par défaut des PC comprises.
11. Ne saute AUCUNE étape de configuration et respecte l'ORDRE des étapes du TP : si une étape change un réglage fait plus tôt (ex. mode VTP transparent puis client), produis les commandes dans le même ordre, car l'état final en dépend.
8. Ignore les questions de réflexion et les vérifications (ping, show, traceroute) : uniquement de la configuration.
"""


def gemini_key() -> str:
    key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY") or ""
    if not key and IS_WINDOWS:
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as k:
                key = str(winreg.QueryValueEx(k, "GEMINI_API_KEY")[0] or "")
        except Exception:
            pass
    return key


def png_bytes(img, max_side: int = 1600) -> bytes:
    img = img.convert("RGB")
    if max(img.size) > max_side:
        img.thumbnail((max_side, max_side))
    buf = io.BytesIO()
    img.save(buf, "PNG")
    return buf.getvalue()


def parse_json_loose(raw: str) -> dict:
    raw = re.sub(r"```(?:json)?", "", raw or "").strip()
    start, end = raw.find("{"), raw.rfind("}")
    if start < 0 or end <= start:
        raise ValueError("La réponse de Gemini ne contient pas de JSON exploitable.")
    return json.loads(raw[start:end + 1])


def gemini_plan(text: str, pdf: bytes | None, images: list, net: dict, net_err: str = "",
                system_prompt: str | None = None) -> dict:
    client = genai.Client(api_key=gemini_key())
    parts = []
    if pdf:
        parts.append(genai_types.Part.from_bytes(data=pdf, mime_type="application/pdf"))
    for img in images[: CONFIG["max_images"]]:
        parts.append(genai_types.Part.from_bytes(data=png_bytes(img), mime_type="image/png"))
    if net_err:
        net_txt = ("ÉTAT ACTUEL DU RÉSEAU : INCONNU (lecture impossible). La topologie de l'activité peut "
                   "déjà exister : utilise exactement les noms d'équipements et de ports des consignes.")
    else:
        net_txt = ("ÉTAT ACTUEL DU RÉSEAU DANS PACKET TRACER (JSON, vide si la maquette est vide) :\n"
                   + network_for_llm(net))
    parts.append(
        f"{net_txt}\n\n"
        "CONSIGNES (texte extrait, peut être incomplet ; voir aussi PDF/captures jointes) :\n"
        f"<consignes>\n{text}\n</consignes>\n\nProduis le plan JSON.")
    log.info("Analyse par Gemini (%s) : %s%d image(s)...", CONFIG["gemini_model"],
             "1 PDF, " if pdf else "", min(len(images), CONFIG["max_images"]))
    resp = client.models.generate_content(
        model=CONFIG["gemini_model"],
        contents=parts,
        config=genai_types.GenerateContentConfig(
            system_instruction=system_prompt or SYSTEM_PROMPT,
            response_mime_type="application/json",
            max_output_tokens=CONFIG["gemini_max_tokens"],
            temperature=0.2,
            automatic_function_calling=genai_types.AutomaticFunctionCallingConfig(disable=True),
        ),
    )
    if not (resp.text or "").strip():
        raise RuntimeError("réponse vide (quota, filtrage ou limite de tokens)")
    return parse_json_loose(resp.text)


def analyze(text: str, pdf: bytes | None, images: list, net: dict, net_err: str = "",
            system_prompt: str | None = None) -> dict:
    if genai is not None and gemini_key():
        try:
            return gemini_plan(text, pdf, images, net, net_err, system_prompt)
        except Exception as e:
            log.error("Gemini a échoué : %s", e)
            RUN_WARNINGS.append(f"Gemini a échoué ({str(e)[:150]}) : plan de secours limité utilisé.")
    else:
        log.warning("Gemini indisponible (python -m pip install google-genai / variable GEMINI_API_KEY).")
        RUN_WARNINGS.append("Gemini indisponible (clé GEMINI_API_KEY absente ?) : plan de secours limité.")
    if text.strip():
        log.warning("-> parseur de secours : table d'adressage uniquement, sans câblage.")
        return regex_plan(text)
    raise RuntimeError("Impossible d'analyser les consignes sans Gemini (aucun texte exploitable).")


# =============================================================================
# PARSEUR DE SECOURS (sans Gemini) : table d'adressage
# =============================================================================
IP_RE = r"\d{1,3}(?:\.\d{1,3}){3}"
ROW_RE = re.compile(
    rf"^\s*(?:(?P<dev>[A-Za-z][\w\-]*)\s+)?"
    rf"(?P<intf>NIC|[A-Za-z]{{1,16}}\s?\d+(?:/\d+)*(?:\.\d+)?)\s+"
    rf"(?P<ip>{IP_RE})\s+(?P<mask>{IP_RE})"
    rf"(?:\s+(?P<gw>{IP_RE}|N/?A|S\.?O\.?|-))?", re.IGNORECASE)
_IF_PATTERNS = [
    (r"(?:gigabitethernet|gigabit|gig|gi|g)", "GigabitEthernet"),
    (r"(?:fastethernet|fast|fa|f)", "FastEthernet"),
    (r"(?:ethernet|eth|e)", "Ethernet"),
    (r"(?:serial|ser|se|s)", "Serial"),
    (r"(?:vlan|vl)", "Vlan"),
    (r"(?:loopback|lo)", "Loopback"),
]


def expand_interface(name: str) -> str:
    s = str(name).strip()
    if s.upper() == "NIC":
        return "FastEthernet0"
    for pat, full in _IF_PATTERNS:
        m = re.fullmatch(pat + r"\s*(\d+(?:/\d+)*(?:\.\d+)?)", s, re.IGNORECASE)
        if m:
            return full + m.group(1)
    return s


def guess_type(name: str) -> str:
    n = str(name).upper()
    if re.match(r"^(PC|H\d|HOST|CLIENT|POSTE|WS)", n):
        return "pc"
    if re.match(r"^(LAPTOP|PORTABLE)", n):
        return "laptop"
    if re.match(r"^(SRV|SERV)", n):
        return "server"
    if re.match(r"^(PRINTER|IMPRIMANTE)", n):
        return "printer"
    if re.match(r"^(MLS|DLS|L3|CORE)", n):
        return "multilayerswitch"
    if re.match(r"^(S\d|SW|S-|ALS|ASW|DSW|SWITCH|COMMUTATEUR)", n):
        return "switch"
    return "router"


def regex_plan(text: str) -> dict:
    devices, ios, hosts, current = {}, {}, [], None
    for line in text.splitlines():
        m = ROW_RE.match(line)
        if not m:
            continue
        dev = m.group("dev") or current
        if not dev:
            continue
        current = dev
        intf = expand_interface(m.group("intf"))
        ip, mask, gw = m.group("ip"), m.group("mask"), m.group("gw") or ""
        gw = gw if re.fullmatch(IP_RE, gw) else ""
        dtype = guess_type(dev)
        devices.setdefault(dev, {"name": dev, "type": dtype})
        if dtype in HOST_TYPES:
            hosts.append({"name": dev, "dhcp": False, "ip": ip, "mask": mask, "gateway": gw})
            continue
        cfg = ios.setdefault(dev, [f"hostname {dev}"])
        cfg.append(f"interface {intf}")
        sub = re.search(r"\.(\d+)$", intf)
        if sub:
            cfg.append(f" encapsulation dot1Q {sub.group(1)}")
        cfg += [f" ip address {ip} {mask}", " no shutdown", " exit"]
        if dtype in ("switch", "multilayerswitch") and gw and f"ip default-gateway {gw}" not in cfg:
            cfg.append(f"ip default-gateway {gw}")
    for cfg in ios.values():
        parents = {c.split()[1].split(".")[0] for c in cfg if c.startswith("interface ") and "." in c}
        for p in sorted(parents):
            if f"interface {p}" not in cfg:
                cfg[1:1] = [f"interface {p}", " no shutdown", " exit"]
    return {"devices": list(devices.values()), "modules": [], "links": [], "ios_configs": ios,
            "hosts": hosts, "notes": ["Plan de secours (sans Gemini) : table d'adressage uniquement."]}


# =============================================================================
# NORMALISATION DU PLAN
# =============================================================================
_FORBIDDEN_CMD = re.compile(
    r"^(en|enable|conf t|config t|configure terminal|end|wr|write|write memory|"
    r"copy run start|copy running-config startup-config)$", re.IGNORECASE)
TIER = {"router": 0, "multilayerswitch": 1, "switch": 1}


def type_from_model(model) -> str | None:
    m = str(model or "")
    if m in ROUTER_MODELS:
        return "router"
    if m in ("2950-24", "2950T-24", "2960-24TT", "Switch-PT"):
        return "switch"
    if m in ("3560-24PS", "3650-24PS"):
        return "multilayerswitch"
    return {"PC-PT": "pc", "Server-PT": "server", "Laptop-PT": "laptop", "Printer-PT": "printer"}.get(m)


def default_link_type(ta: str, tb: str, port_a: str) -> str:
    if port_a.lower().startswith("serial"):
        return "serial"
    cat = {"router": "R", "pc": "H", "server": "H", "laptop": "H", "printer": "H"}
    ca, cb = cat.get(ta, "S"), cat.get(tb, "S")
    return "cross" if ca == cb or {ca, cb} == {"R", "H"} else "straight"


def normalize_plan(plan: dict, net: dict) -> dict:
    plan = dict(plan or {})
    for key, default in (("devices", []), ("modules", []), ("links", []),
                         ("ios_configs", {}), ("hosts", []), ("manuel", []), ("notes", [])):
        if not isinstance(plan.get(key), type(default)):
            plan[key] = default
    existing = net["devices"]
    devs: dict[str, dict] = {}
    for d in plan["devices"]:
        if not isinstance(d, dict) or not str(d.get("name", "")).strip():
            continue
        name = str(d["name"]).strip()
        t = str(d.get("type") or "").lower().replace(" ", "").replace("-", "")
        if t not in DEFAULT_MODELS:
            t = type_from_model(d.get("model")) or guess_type(name)
        model = str(d.get("model") or "")
        if model not in SUPPORTED_MODELS:
            model = DEFAULT_MODELS[t]
        devs[name] = {"name": name, "type": t, "model": model, "x": d.get("x"), "y": d.get("y")}

    def dtype(name):
        if name in devs:
            return devs[name]["type"]
        if name in existing:
            return type_from_model(existing[name].get("model")) or guess_type(name)
        return guess_type(name)

    def ensure(name):
        if name and name not in devs and name not in existing:
            t = guess_type(name)
            devs[name] = {"name": name, "type": t, "model": DEFAULT_MODELS[t], "x": None, "y": None}

    links = []
    for l in plan["links"]:
        try:
            a, b = str(l["a"]), str(l["b"])
            pa, pb = expand_interface(l["a_port"]), expand_interface(l["b_port"])
        except (KeyError, TypeError):
            continue
        ensure(a)
        ensure(b)
        lt = str(l.get("type") or "").lower().replace("ethernet-", "")
        if lt in ("", "straight", "cross", "auto") or lt not in LINK_TYPES:
            lt = default_link_type(dtype(a), dtype(b), pa)
        links.append({"a": a, "a_port": pa, "b": b, "b_port": pb, "type": lt})
    plan["links"] = links

    configs = {}
    for name, cmds in plan["ios_configs"].items():
        ensure(name)
        lines = cmds if isinstance(cmds, list) else str(cmds).splitlines()
        configs[name] = [str(c) for c in lines if str(c).strip() and not _FORBIDDEN_CMD.match(str(c).strip())]
    plan["ios_configs"] = configs

    plan["hosts"] = [h for h in plan["hosts"] if isinstance(h, dict) and h.get("name")]
    for h in plan["hosts"]:
        ensure(h["name"])
    plan["modules"] = [{"device": str(m["device"]), "slot": str(m["slot"]), "model": str(m["model"])}
                       for m in plan["modules"]
                       if isinstance(m, dict) and {"device", "slot", "model"} <= m.keys()]

    rows: dict[int, list] = {}
    for d in devs.values():
        if not (isinstance(d.get("x"), (int, float)) and isinstance(d.get("y"), (int, float))):
            rows.setdefault(TIER.get(d["type"], 2), []).append(d)
    for tier, items in rows.items():
        for i, d in enumerate(items):
            d["x"], d["y"] = 150 + i * 160, 100 + tier * 170
    plan["devices"] = list(devs.values())
    return plan


# =============================================================================
# APPLICATION DU PLAN DANS PACKET TRACER
# =============================================================================
IOS_TYPES = {"router", "switch", "multilayerswitch"}
PROBE = "PTAUTO-SONDE"


class PortProbe:
    """Teste si le port d'un équipement est libre SANS rien changer au final : un PC
    temporaire tente de s'y câbler ; si ça marche, le câble et le PC sont retirés aussitôt.
    (Nécessaire car l'extension ne sait pas dire quel équipement porte un câble existant.)"""

    def __init__(self, call):
        self.call, self.ready = call, None

    async def free(self, dev: str, port: str) -> bool | None:
        """True = libre ; False = occupé (ou incompatible) ; None = test impossible."""
        if not re.match(r"^(GigabitEthernet|FastEthernet|Ethernet)\d", port, re.IGNORECASE):
            return None
        if self.ready is None:
            res = await self.call("addDevice", deviceName=PROBE, deviceModel="PC-PT", x=40, y=40)
            self.ready = bool(res.get("success"))
        if not self.ready:
            return None
        res = await self.call("addLink", device1Name=PROBE, device1Interface="FastEthernet0",
                              device2Name=dev, device2Interface=port, linkType="auto")
        if res.get("success"):
            await self.call("removeLink", links=[{"device": PROBE, "port": "FastEthernet0"}])
            return True
        return False

    async def close(self) -> None:
        if self.ready:
            await self.call("removeDevice", deviceNames=[PROBE])
_PHYS_IF = re.compile(r"^(GigabitEthernet|FastEthernet|Ethernet|Serial)\d", re.IGNORECASE)


def ports_needed(plan: dict, name: str) -> set[str]:
    """Ports physiques qu'un équipement doit posséder d'après le plan (câbles + config IOS)."""
    need = set()
    for l in plan["links"]:
        if l["a"] == name:
            need.add(l["a_port"])
        if l["b"] == name:
            need.add(l["b_port"])
    for cmd in plan["ios_configs"].get(name, []):
        m = re.match(r"^\s*interface\s+(\S+)\s*$", cmd, re.IGNORECASE)
        if m:
            itf = expand_interface(m.group(1)).split(".")[0]
            if _PHYS_IF.match(itf):
                need.add(itf)
    return need


async def apply_plan(bridge: Bridge, plan: dict, net: dict, net_err: str = "",
                     recabler: bool = False) -> list[tuple[str, str, str]]:
    report: list[tuple[str, str, str]] = []
    tags = {"OK": "[OK]     ", "ECHEC": "[ECHEC]  ", "DEJA": "[DEJA]   ", "VERIF": "[VERIF]  "}

    async def call(tool: str, **kwargs) -> dict:
        try:
            return await bridge.call(tool, **kwargs)
        except Exception as e:
            return {"success": False, "error": str(e)}

    def note(status: str, label: str, msg: str = "") -> None:
        detail = f" -> {msg}" if msg and status != "OK" else ""
        (log.warning if status in ("ECHEC", "VERIF") else log.info)("%s%s%s", tags[status], label, detail)
        report.append((status, label, msg))

    async def act(label: str, tool: str, **kwargs) -> bool:
        res = await call(tool, **kwargs)
        ok = bool(res.get("success"))
        note("OK" if ok else "ECHEC", label, str(res.get("message") or res.get("error") or ""))
        return ok

    ports = {n: {x.lower() for x in d["ports"]} for n, d in net["devices"].items()}
    dtypes = {d["name"]: d["type"] for d in plan["devices"]}
    existing, created = set(net["devices"]), set()

    # --- 1. Équipements manquants ---
    for d in plan["devices"]:
        n = d["name"]
        if n in existing:
            continue
        if await device_exists(bridge, n):          # sécurité : jamais de doublon
            note("DEJA", f"Ajout de {n}", "existe déjà dans l'activité")
            existing.add(n)
            continue
        if await act(f"Ajout de {n} ({d['model']})", "addDevice", deviceName=n,
                     deviceModel=d["model"], x=int(d["x"]), y=int(d["y"])):
            created.add(n)

    # --- 2. Modules (équipements créés OU déjà présents) ---
    modules_added = False
    for m in plan["modules"]:
        dev = m["device"]
        label = f"Module {m['model']} sur {dev} (slot {m['slot']})"
        if dev not in created and dev not in existing:
            note("ECHEC", label, "équipement introuvable")
            continue
        if dev in existing and dev in ports:
            need = ports_needed(plan, dev)
            if need and all(x.lower() in ports[dev] for x in need):
                note("DEJA", label, "les ports requis existent déjà")
                continue
            if dtypes.get(dev, guess_type(dev)) in IOS_TYPES:
                # Installer un module éteint puis rallume l'équipement :
                # on sauvegarde d'abord sa configuration (write memory) pour ne rien perdre.
                if (await call("configureIosDevice", deviceName=dev, commands="")).get("success"):
                    log.info("         configuration de %s sauvegardée avant le redémarrage", dev)
        modules_added |= await act(label, "addModule", deviceName=dev, slot=m["slot"], model=m["model"])
    if modules_added:
        fresh, err, _ = await read_network(bridge)
        if not err:
            ports = {n: {x.lower() for x in d["ports"]} for n, d in fresh["devices"].items()}

    # --- 3. Câbles ---
    known_pairs = [tuple(sorted((a.lower(), b.lower()))) for a, b in net["pairs"]]
    probe = PortProbe(call)
    if await device_exists(bridge, PROBE):            # reste d'une exécution interrompue
        await call("removeDevice", deviceNames=[PROBE])
    try:
        for l in plan["links"]:
            a, pa, b, pb = l["a"], l["a_port"], l["b"], l["b_port"]
            label = f"Câble {a}:{pa} <-> {b}:{pb} ({l['type']})"
            missing = [f"{d}:{x}" for d, x in ((a, pa), (b, pb)) if d in ports and x.lower() not in ports[d]]
            if missing:
                note("ECHEC", label, f"port inexistant {', '.join(missing)} (module manquant ?)")
                continue
            kw = dict(device1Name=a, device1Interface=pa, device2Name=b, device2Interface=pb, linkType=l["type"])
            res = await call("addLink", **kw)
            if res.get("success"):
                note("OK", label)
                continue
            # Échec : déjà câblé, port pris par un autre câble, ou câble incompatible ?
            fa, fb = await probe.free(a, pa), await probe.free(b, pb)
            pair = tuple(sorted((pa.lower(), pb.lower())))
            if fa is True and fb is True:
                note("ECHEC", label, f"refusé par Packet Tracer alors que les deux ports sont libres "
                                     f"(type de câble ou de port incompatible ?) [{res.get('error')}]")
                continue
            if fa is True or fb is True:
                busy = [(b, pb)] if fa is True else [(a, pa)]
                why = f"{busy[0][0]}:{busy[0][1]} est relié à un autre équipement"
            elif pair in known_pairs:
                known_pairs.remove(pair)
                note("DEJA", label, "déjà câblé")
                continue
            elif net_err and a not in created and b not in created:
                note("DEJA", label, "réseau illisible : probablement déjà câblé")
                continue
            else:
                busy, why = [(a, pa), (b, pb)], "les ports sont occupés par d'autres câbles"
            if recabler:
                for d, x in busy:
                    await call("removeLink", links=[{"device": d, "port": x}])
                if (await call("addLink", **kw)).get("success"):
                    note("OK", label + f" [recâblé : {why}]")
                    continue
            note("VERIF", label, why + " -> si les consignes demandent de corriger ce câblage, "
                                       "relancez avec --recabler")
    finally:
        await probe.close()

    # --- 4. Configuration IOS ---
    for name, cmds in plan["ios_configs"].items():
        if cmds:
            await act(f"Configuration IOS de {name} ({len(cmds)} commandes)", "configureIosDevice",
                      deviceName=name, commands="\n".join(cmds))

    # --- 5. Adressage des PC / serveurs ---
    for h in plan["hosts"]:
        kw = {"deviceName": h["name"], "dhcpEnabled": bool(h.get("dhcp"))}
        if not h.get("dhcp"):
            for src, dst in (("ip", "ipaddress"), ("mask", "subnetMask"),
                             ("gateway", "defaultGateway"), ("dns", "dnsServer")):
                if h.get(src):
                    kw[dst] = str(h[src])
        what = "DHCP" if h.get("dhcp") else f"{h.get('ip', '?')}/{h.get('mask', '?')}"
        await act(f"Adressage de {h['name']} ({what})", "configurePcIp", **kw)
    return report


# =============================================================================
# ORCHESTRATION
# =============================================================================
def summarize_plan(plan: dict) -> None:
    log.info("Plan : %d équipement(s), %d module(s), %d câble(s), %d config(s) IOS, %d hôte(s).",
             len(plan["devices"]), len(plan["modules"]), len(plan["links"]),
             len(plan["ios_configs"]), len(plan["hosts"]))
    for note in plan.get("notes", []):
        log.info("  note : %s", note)
    if plan.get("manuel"):
        log.info("  %d action(s) manuelle(s) seront listées à la fin.", len(plan["manuel"]))


def latest_plan_names() -> list[str]:
    plans = sorted(Path(CONFIG["runs_dir"]).glob("*/plan.json"))
    for pl in reversed(plans):
        try:
            return [d["name"] for d in json.loads(pl.read_text(encoding="utf-8")).get("devices", [])]
        except Exception:
            continue
    return []


async def diagnostic(bridge: Bridge, run_dir: Path) -> int:
    print("\n===== DIAGNOSTIC =====")
    net, err, raw = await read_network(bridge)
    dump = json.dumps(raw, indent=2, ensure_ascii=False, default=str)
    (run_dir / "diagnostic_getNetwork.json").write_text(dump, encoding="utf-8")
    if err:
        print(f"getNetwork : ÉCHEC -> {err}")
    else:
        print(f"getNetwork : OK -> {len(net['devices'])} équipement(s), {len(net['pairs'])} câble(s)")
        for name, d in net["devices"].items():
            print(f"   - {name} ({d['model']}) : {compress_ports(d['ports'])}")
        for a, b in net["pairs"]:
            print(f"   câble : {a} <-> {b}")
    names = latest_plan_names()
    if names:
        print("\nPrésence des équipements du dernier plan :")
        for n in names:
            ex = await device_exists(bridge, n)
            print(f"   - {n:<12} {'PRÉSENT' if ex else 'absent' if ex is False else 'inconnu'}")
    try:
        cl = await bridge.call("getCommandLog", limit=3)
        print("\ngetCommandLog :", "OK" if cl.get("success") else f"ÉCHEC -> {cl.get('error')}")
    except Exception as e:
        print("\ngetCommandLog : ÉCHEC ->", e)
    print(f"\nDétails enregistrés dans {run_dir.resolve()}")
    return 0


def list_models() -> None:
    need(genai, "google-genai")
    if not gemini_key():
        raise RuntimeError("Variable GEMINI_API_KEY absente.")
    client = genai.Client(api_key=gemini_key())
    names = sorted(m.name.replace("models/", "") for m in client.models.list()
                   if "generateContent" in (m.supported_actions or []))
    print("Modèles Gemini utilisables avec --modele :")
    for n in names:
        print("  ", n)


WAIT_TITLE = "PT Auto - en attente de Packet Tracer"


async def connect_packet_tracer(bridge: Bridge, timeout: float) -> bool:
    """Attend la connexion de l'extension ; ouvre au besoin Extensions > Packet Tracer MCP."""
    hide = CONFIG["masquer_pont"] and pt_ui is not None and IS_WINDOWS
    if await bridge.wait(3):
        if hide:
            pt_ui.hide_mcp_window()             # ouverte à la main ou visible : on la cache
        return True
    if pt_ui is not None and IS_WINDOWS:
        log.info("Ouverture automatique de Extensions > Packet Tracer MCP...")
        opened = pt_ui.open_mcp_window(hidden=hide)   # fil principal : exigence COM de UI Automation
        if opened and await bridge.wait(15):
            return True
        if not pt_ui.main_window():
            log.warning("Packet Tracer n'est pas ouvert.")
    log.info("En attente de Packet Tracer... Dans Packet Tracer : Extensions > Packet Tracer MCP")
    box = None
    if HEADLESS and pt_ui is not None:          # message non bloquant, refermé dès la connexion
        box = asyncio.ensure_future(asyncio.to_thread(
            pt_ui.message, "Packet Tracer n'est pas encore relié.\n\nOuvrez votre activité, puis cliquez "
            "dans Packet Tracer sur :\n    Extensions > Packet Tracer MCP\n\nCe message se ferme tout "
            "seul dès que la liaison est établie.", WAIT_TITLE, "warning"))
    ok = await bridge.wait(timeout)
    if ok and hide:
        pt_ui.hide_mcp_window()
    for _ in range(20):                         # le message doit être fermé, sinon le script attendrait
        if box is None or box.done():
            break
        pt_ui.close_window(WAIT_TITLE)
        await asyncio.sleep(0.3)
    return ok


def final_popup(counts: dict, manual: list[str], rapport: Path) -> None:
    if not HEADLESS:
        return
    lines = [f"Terminé : {counts['OK']} réussite(s), {counts['ECHEC']} échec(s), "
             f"{counts['DEJA']} déjà en place, {counts['VERIF']} à vérifier."]
    if RUN_WARNINGS:
        lines += ["", "Attention :"] + [f"  - {w}" for w in RUN_WARNINGS]
    if manual:
        lines += ["", "À faire à la main :"] + [f"  - {m}" for m in manual[:8]]
        if len(manual) > 8:
            lines.append(f"  ... et {len(manual) - 8} autre(s) dans le rapport")
    lines += ["", "Contrôlez le score avec « Check Results ».", "", "Ouvrir le rapport détaillé ?"]
    kind = "warning" if counts["ECHEC"] or RUN_WARNINGS else "info"
    if popup("\n".join(lines), kind, "yesno") == "yes":
        try:
            os.startfile(str(rapport))
        except Exception:
            pass


async def run(args) -> int:
    run_dir = Path(CONFIG["runs_dir"]) / datetime.now().strftime("%Y%m%d-%H%M%S")
    run_dir.mkdir(parents=True, exist_ok=True)

    bridge = Bridge(CONFIG["bridge_host"], CONFIG["bridge_port"], CONFIG["tool_timeout"])
    try:
        await bridge.start()
    except RuntimeError:
        # Une résolution précédente, invisible car sans terminal, est restée bloquée.
        if pt_ui is None or popup("Une résolution précédente semble bloquée en arrière-plan.\n\n"
                                  "L'arrêter et continuer ?", "question", "yesno") == "no":
            raise
        n = pt_ui.kill_stale_runs()
        log.warning("Résolution(s) bloquée(s) arrêtée(s) : %d", n)
        await bridge.start()
    try:
        connected = await connect_packet_tracer(bridge, 20 if args.apercu else CONFIG["connect_timeout"])
        if not connected and (args.diagnostic or not args.apercu):
            raise RuntimeError("Packet Tracer ne s'est pas connecté. Vérifiez que la fenêtre "
                               "Extensions > Packet Tracer MCP est ouverte.")

        if args.diagnostic:
            return await diagnostic(bridge, run_dir)

        if connected:
            net, net_err, raw = await read_network(bridge)
        else:
            net, net_err, raw = parse_network({}), "Packet Tracer non connecté", None
        (run_dir / "reseau_avant.json").write_text(json.dumps(raw, indent=2, ensure_ascii=False, default=str),
                                                   encoding="utf-8")
        if net_err:
            log.warning("LECTURE DU RÉSEAU IMPOSSIBLE : %s", net_err)
            log.warning("-> les équipements existants seront détectés un par un (aucun doublon ne sera créé).")
        else:
            log.info("Réseau actuel : %d équipement(s), %d câble(s) : %s",
                     len(net["devices"]), len(net["pairs"]), ", ".join(net["devices"]) or "maquette vide")

        if args.plan:
            plan = json.loads(Path(args.plan).read_text(encoding="utf-8"))
            log.info("Plan chargé depuis %s", args.plan)
        else:
            text, pdf, images = await asyncio.to_thread(gather_instructions, args.consignes)
            (run_dir / "consignes.txt").write_text(text, encoding="utf-8")
            for i, img in enumerate(images, 1):
                img.save(run_dir / f"capture_{i:02d}.png")
            plan = await asyncio.to_thread(analyze, text, pdf, images, net, net_err)

        plan = normalize_plan(plan, net)
        (run_dir / "plan.json").write_text(json.dumps(plan, indent=2, ensure_ascii=False), encoding="utf-8")
        summarize_plan(plan)

        if args.apercu:
            log.info("Aperçu terminé : rien n'a été modifié. Plan : %s", (run_dir / "plan.json").resolve())
            if popup(f"Aperçu terminé : rien n'a été modifié.\n\n{len(plan['devices'])} équipement(s), "
                     f"{len(plan['links'])} câble(s), {len(plan['ios_configs'])} config(s) IOS.\n\n"
                     "Ouvrir le plan ?", "info", "yesno") == "yes":
                os.startfile(str(run_dir / "plan.json"))
            return 0

        log.info("Application du plan dans Packet Tracer...")
        report = await apply_plan(bridge, plan, net, net_err, args.recabler)
        after, after_err, _ = await read_network(bridge)
        if not after_err:          # contrôle final : chaque équipement a-t-il tous les ports requis ?
            for d in plan["devices"]:
                have = {x.lower() for x in after["devices"].get(d["name"], {}).get("ports", [])}
                lack = sorted(x for x in ports_needed(plan, d["name"]) if have and x.lower() not in have)
                if lack:
                    log.warning("[VERIF]  %s n'a pas les ports %s (module manquant ?)", d["name"], ", ".join(lack))
                    report.append(("VERIF", f"Ports de {d['name']}", "absents : " + ", ".join(lack)))

        counts = {k: sum(1 for r in report if r[0] == k) for k in ("OK", "ECHEC", "DEJA", "VERIF")}
        lines = [f"[{s}] {label}" + (f" -> {msg}" if s != "OK" and msg else "") for s, label, msg in report]
        manual = [str(x) for x in plan.get("manuel", []) if str(x).strip()]
        if manual:
            lines += ["", "À FAIRE À LA MAIN :"] + [f"  - {x}" for x in manual]
        (run_dir / "rapport.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
        log.info("=" * 60)
        log.info("TERMINÉ : %d réussite(s), %d échec(s), %d déjà en place, %d à vérifier.",
                 counts["OK"], counts["ECHEC"], counts["DEJA"], counts["VERIF"])
        if after_err:
            log.warning("Réseau final illisible : %s", after_err)
        else:
            log.info("Réseau final : %d équipement(s), %d câble(s).",
                     len(after["devices"]), len(after["pairs"]))
        log.info("Rapport : %s", (run_dir / "rapport.txt").resolve())
        if manual:
            log.info("-" * 60)
            log.info("À FAIRE À LA MAIN (non automatisable) :")
            for x in manual:
                log.info("  - %s", x)
        log.info("Vérifiez le score avec « Check Results » dans la fenêtre d'instructions.")
        final_popup(counts, manual, run_dir / "rapport.txt")
        return 1 if counts["ECHEC"] else 0
    finally:
        await bridge.stop()


def main() -> None:
    ap = argparse.ArgumentParser(description="PT Auto v2 - résolution automatique d'activités Packet Tracer")
    ap.add_argument("consignes", nargs="?", help="fichier de consignes (PDF, TXT, PNG/JPG), facultatif")
    ap.add_argument("--apercu", action="store_true", help="analyser sans rien modifier")
    ap.add_argument("--plan", help="appliquer un plan.json existant (éventuellement corrigé)")
    ap.add_argument("--modele", help="modèle Gemini (défaut : gemini-flash-latest)")
    ap.add_argument("--modeles", action="store_true", help="lister les modèles Gemini disponibles")
    ap.add_argument("--diagnostic", action="store_true", help="tester la lecture du réseau, sans rien modifier")
    ap.add_argument("--tester-cle", action="store_true", help="vérifier que la clé Gemini est acceptée")
    ap.add_argument("--montrer-pont", action="store_true",
                    help="ramener à l'écran la fenêtre Packet Tracer MCP (dépannage)")
    ap.add_argument("--pont-visible", action="store_true",
                    help="laisser la fenêtre Packet Tracer MCP visible pendant la résolution")
    ap.add_argument("--recabler", action="store_true",
                    help="remplacer un câble existant qui occupe un port requis par le plan")
    args = ap.parse_args()
    global HEADLESS
    if sys.stdout is None:
        HEADLESS = True
    setup_logging()
    if args.modele:
        CONFIG["gemini_model"] = args.modele
    if args.pont_visible or (HERE / "pont_visible.flag").exists():
        CONFIG["masquer_pont"] = False
    if args.montrer_pont:
        ok = pt_ui is not None and pt_ui.show_mcp_window()
        print("Fenêtre du pont ramenée à l'écran." if ok else "Fenêtre « Packet Tracer MCP » introuvable.")
        popup("Fenêtre du pont ramenée à l'écran." if ok else "Fenêtre « Packet Tracer MCP » introuvable.")
        return
    if args.modeles:
        try:
            list_models()
        except Exception as e:
            log.error("%s", e)
        return
    if args.tester_cle:
        try:
            need(genai, "google-genai")
            if not gemini_key():
                raise RuntimeError("variable GEMINI_API_KEY absente")
            client = genai.Client(api_key=gemini_key())   # conservé : sinon fermé avant la requête
            next(iter(client.models.list()))
            print("  Clé Gemini acceptée.")
            sys.exit(0)
        except Exception as e:
            print(f"  Clé Gemini refusée : {str(e)[:200]}")
            sys.exit(1)
    if socketio is None or web is None:
        log.error("Bibliothèques manquantes : python -m pip install python-socketio aiohttp")
        sys.exit(2)
    if pyautogui is not None:
        pyautogui.FAILSAFE = True
    if not args.diagnostic and not args.plan:
        popup("Résolution du TP en cours.\n\nNe touchez ni la souris ni le clavier jusqu'au message "
              "de fin (environ 1 minute).", "info", timeout_ms=4000)
    try:
        sys.exit(asyncio.run(run(args)))
    except KeyboardInterrupt:
        log.warning("Interrompu.")
        sys.exit(130)
    except RuntimeError as e:
        log.error("%s", e)
        popup(f"Arrêt : {e}\n\nJournal : {LOG_FILE}", "error")
        sys.exit(1)
    except Exception as e:
        if pyautogui is not None and isinstance(e, pyautogui.FailSafeException):
            log.warning("Arrêt d'urgence : souris placée dans un coin de l'écran.")
            popup("Arrêt d'urgence : la souris a été placée dans un coin de l'écran.", "warning")
            sys.exit(130)
        log.exception("Erreur inattendue")
        popup(f"Erreur inattendue : {e}\n\nJournal : {LOG_FILE}", "error")
        sys.exit(1)


if __name__ == "__main__":
    main()
