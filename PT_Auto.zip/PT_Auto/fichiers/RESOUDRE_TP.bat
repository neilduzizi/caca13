@echo off
rem Resout le TP ouvert dans Packet Tracer, en arriere-plan (pythonw = aucune console).
rem INSTALLER.bat remplace ce fichier par une version qui contient le chemin exact de Python.
setlocal
set "PYW="
for /f "delims=" %%P in ('where pythonw.exe 2^>nul') do if not defined PYW set "PYW=%%P"
if not defined PYW for /f "delims=" %%P in ('where pyw.exe 2^>nul') do if not defined PYW set "PYW=%%P"
if not defined PYW (
  echo Python est introuvable : lancez d'abord INSTALLER.bat
  pause
  exit /b 1
)
start "" "%PYW%" "%~dp0pt_auto.py" %*
