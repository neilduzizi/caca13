@echo off
rem Mode pas a pas avec fenetre de journal (depannage). Utilisez plutot le raccourci du Bureau.
chcp 65001 >nul
cd /d "%~dp0"
python pt_pas_a_pas.py %*
echo.
pause
