# -*- coding: utf-8 -*-
"""
pt_setup - Préparation de Packet Tracer pour PT Auto (lancé par INSTALLER.bat).

1. Trouve Packet Tracer et le démarre si besoin.
2. Teste la chaîne complète : si l'extension répond déjà, il n'y a rien à faire.
3. Sinon, enregistre cisco-pt-mcp.pts automatiquement
   (Extensions > Scripting > Configure PT Script Modules > Add).
4. Si l'automatisation échoue, guide l'utilisateur pas à pas (chemin déjà copié).
5. Vérifie à chaque fois par une vraie connexion du pont et une lecture du réseau.
"""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import pt_ui  # noqa: E402

try:
    import pyperclip
except Exception:
    pyperclip = None


def say(msg: str = "") -> None:
    print(msg, flush=True)


def ask_enter(msg: str) -> None:
    say(f"\n  >>> {msg}, puis appuyez sur Entrée dans cette fenêtre.")
    try:
        input()
    except EOFError:
        pass


FLAG_VISIBLE = HERE / "pont_visible.flag"   # présent = ne pas cacher la fenêtre du pont


async def _getnet(bridge) -> tuple[bool, str]:
    try:
        res = await bridge.call("getNetwork")
    except Exception as e:
        return False, str(e)
    return bool(res.get("success")), str(res.get("error") or "")


async def _verify(auto_open: bool) -> bool:
    import pt_auto
    bridge = pt_auto.Bridge("127.0.0.1", pt_auto.CONFIG["bridge_port"], 20)
    try:
        await bridge.start()
    except RuntimeError:
        n = pt_ui.kill_stale_runs()                 # résolution invisible restée bloquée ?
        if n:
            say(f"  Une ancienne résolution bloquée en arrière-plan a été arrêtée ({n}).")
        try:
            await bridge.start()
        except RuntimeError as e:
            say(f"  [!] La liaison est occupée par un autre programme : {e}")
            say("      Redémarrez l'ordinateur puis relancez INSTALLER.bat.")
            return False
    try:
        ok = await bridge.wait(3)
        if not ok and auto_open:
            pt_ui.open_mcp_window(hidden=False)     # fil principal : exigence COM de UI Automation
            ok = await bridge.wait(15)
        if not ok:
            say("  [!] La fenêtre « Packet Tracer MCP » ne s'est pas connectée.")
            return False
        good, err = await _getnet(bridge)            # aller-retour réel avec Packet Tracer
        if not good:
            say(f"  [!] Packet Tracer est relié mais répond une erreur : {err}")
            return False
        # Test du masquage : la liaison doit survivre à la mise à l'écart de la fenêtre.
        if FLAG_VISIBLE.exists() or not pt_ui.hide_mcp_window():
            return True
        await asyncio.sleep(2)
        good, err = await _getnet(bridge)
        if not good and not await bridge.wait(10):
            good = False
        elif not good:
            good, err = await _getnet(bridge)
        if good:
            say("  [OK] Fenêtre « Packet Tracer MCP » rendue invisible, liaison intacte.")
            return True
        pt_ui.show_mcp_window()
        FLAG_VISIBLE.write_text("La liaison ne survit pas au masquage sur ce PC.\n", encoding="utf-8")
        say("  [!] Sur ce PC, cacher la fenêtre « Packet Tracer MCP » coupe la liaison :")
        say("      elle restera donc visible (réglage enregistré).")
        ok = await bridge.wait(15)
        return ok and (await _getnet(bridge))[0]
    except Exception as e:
        say(f"  [!] Erreur pendant la vérification : {e}")
        return False
    finally:
        await bridge.stop()


def verify(auto_open: bool = True) -> bool:
    return asyncio.run(_verify(auto_open))


def guided_open_mcp() -> bool:
    say("    Dans Packet Tracer, cliquez sur : Extensions > Packet Tracer MCP")
    say("    (une petite fenêtre s'ouvre : laissez-la ouverte)")
    ask_enter("Faites-le")
    return verify(auto_open=False)


def main() -> int:
    pts = HERE / "cisco-pt-mcp.pts"
    if not pts.exists():
        say(f"  [X] Fichier introuvable : {pts}")
        return 2

    # --- 1. Packet Tracer en cours d'exécution ---
    win = pt_ui.main_window()
    if not win:
        exe = pt_ui.find_pt_exe()
        if not exe:
            say("  [X] Packet Tracer est introuvable. Installez-le, puis relancez INSTALLER.bat.")
            return 2
        say(f"  Démarrage de Packet Tracer : {exe}")
        say("  Si une fenêtre de connexion (compte Cisco / NetAcad) apparaît, connectez-vous.")
        say("  Le script attend jusqu'à 5 minutes...")
        pt_ui.launch_pt(exe)
        win = pt_ui.wait_main_window(300)
        if not win:
            say("  [X] La fenêtre principale de Packet Tracer n'est pas apparue.")
            return 2
    say(f"  Packet Tracer détecté : « {win['title']} »")

    # --- 2. Déjà fonctionnel ? ---
    say("  Test de l'extension cisco-pt-mcp...")
    if verify():
        say("  [OK] L'extension est déjà installée et répond : rien à faire.")
        return 0

    # --- 3. Enregistrement automatique ---
    say("  Enregistrement automatique du module (ne touchez pas à la souris)...")
    if pt_ui.register_script_module(str(pts)):
        if verify():
            say("  [OK] Module enregistré et pont vérifié.")
            return 0
        say("  [!] Le module est dans la liste mais le pont ne répond pas encore.")
    else:
        say(f"  [!] Enregistrement automatique impossible : {pt_ui.LAST_ERROR}")
        if pt_ui.DUMP_FILE.exists():
            say(f"      Détails de l'interface enregistrés dans : {pt_ui.DUMP_FILE}")

    # --- 4. Repli guidé ---
    say("")
    say("  L'enregistrement automatique n'a pas abouti. Faisons-le ensemble (une seule fois) :")
    if pyperclip:
        pyperclip.copy(str(pts))
        say("  Le chemin du fichier est déjà copié : vous n'aurez qu'à faire Ctrl+V.")
    say("    1. Dans Packet Tracer : Extensions > Scripting > Configure PT Script Modules...")
    say("    2. Cliquez sur « Add... »")
    say(f"    3. Dans la zone « Nom du fichier », faites Ctrl+V ({pts}) puis Entrée")
    say("    4. Fermez la fenêtre des modules")
    ask_enter("Faites ces 4 étapes")
    if verify() or guided_open_mcp():
        say("  [OK] Module enregistré et pont vérifié.")
        return 0

    say("")
    say("  Le menu « Packet Tracer MCP » n'apparaît parfois qu'après un redémarrage.")
    ask_enter("Fermez et rouvrez Packet Tracer")
    if verify() or guided_open_mcp():
        say("  [OK] Module enregistré et pont vérifié.")
        return 0

    say("  [X] Le pont ne répond toujours pas. Lancez DIAGNOSTIC.bat et envoyez le résultat.")
    return 1


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    sys.exit(main())
