﻿#Requires -Version 5.1
<#
  PT Auto - Mise en place complète (lancée par INSTALLER.bat)

  INSTALLER.bat charge ce fichier comme du texte : la politique d'exécution de Windows
  (« l'exécution de scripts est désactivée sur ce système ») ne peut donc pas le bloquer.
  Ne le lancez pas directement : double-cliquez sur INSTALLER.bat.

  1. Copie les fichiers dans le dossier d'installation (C:\pt_auto par défaut)
  2. Trouve Python 3.10 à 3.14, sinon installe Python 3.13 (winget, ou python.org en secours)
  3. Installe les bibliothèques Python
  4. Enregistre la clé Gemini (variable utilisateur GEMINI_API_KEY) et la teste
  5. Crée les raccourcis « Résoudre TP » et « Aperçu TP » sur le Bureau (sans terminal)
  6. Prépare Packet Tracer : enregistre cisco-pt-mcp.pts et vérifie la liaison complète

  Aucun droit administrateur n'est nécessaire. Le script peut être relancé sans risque.
#>
param(
    [string]$InstallDir = 'C:\pt_auto',
    [switch]$SansPacketTracer
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}

# Dossier des fichiers à installer : fourni par INSTALLER.bat (variable PTAUTO_SRC)
$Source = if ($env:PTAUTO_SRC) { $env:PTAUTO_SRC } elseif ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$env:PYTHONIOENCODING = 'utf-8'      # accents corrects dans la sortie de Python
$PyMinor  = '3.13'
$Total    = 6
$Required = @('pt_auto.py', 'pt_pas_a_pas.py', 'pt_ui.py', 'pt_setup.py', 'requirements.txt', 'cisco-pt-mcp.pts')
$Optional = @('LICENSE-cisco-pt-mcp.txt', 'LANCER.bat', 'APERCU.bat', 'DIAGNOSTIC.bat',
              'RESOUDRE_TP.bat', 'MONTRER_PONT.bat', 'PAS_A_PAS.bat', 'pt_installer.ps1')

function Step([int]$n, [string]$text) { Write-Host ''; Write-Host "[$n/$Total] $text" -ForegroundColor Cyan }
function Ok([string]$t)   { Write-Host "  [OK] $t" -ForegroundColor Green }
function Warn([string]$t) { Write-Host "  [!]  $t" -ForegroundColor Yellow }
function Fail([string]$t) { Write-Host "  [X]  $t" -ForegroundColor Red }

function Invoke-Native([string]$Exe, [string[]]$ArgList) {
    # Commande externe : sa sortie s'affiche, seul le code de retour est renvoyé.
    $old = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try { & $Exe @ArgList | Out-Host; return $LASTEXITCODE }
    finally { $ErrorActionPreference = $old }
}

function Update-SessionPath {
    $m = [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $u = [Environment]::GetEnvironmentVariable('Path', 'User')
    $env:Path = [Environment]::ExpandEnvironmentVariables("$m;$u")
}

function Test-Python([string]$Exe, [string[]]$Pre) {
    # Renvoie le chemin de python.exe si c'est un vrai Python 3.10 à 3.14, sinon $null.
    # (Python 3.15+ est écarté : certaines bibliothèques n'ont pas encore de version pour lui.)
    $old = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        $code = 'import sys;print(sys.executable);print(sys.version_info[0]*100+sys.version_info[1])'
        $out = @(& $Exe @Pre -c $code 2>$null)
        if ($LASTEXITCODE -ne 0 -or $out.Count -lt 2) { return $null }
        $ver = [int]$out[1]
        if ($ver -lt 310 -or $ver -gt 314) { return $null }
        if (-not (Test-Path -LiteralPath $out[0])) { return $null }
        return [string]$out[0]
    } catch { return $null }
    finally { $ErrorActionPreference = $old }
}

function Find-Python {
    $cands = @(
        @{ Exe = 'py'; Pre = @("-$PyMinor") }, @{ Exe = 'py'; Pre = @('-3.12') },
        @{ Exe = 'py'; Pre = @('-3.11') },     @{ Exe = 'py'; Pre = @('-3.14') },
        @{ Exe = 'python'; Pre = @() },         @{ Exe = 'python3'; Pre = @() }
    )
    foreach ($c in $cands) {
        if (Get-Command $c.Exe -ErrorAction SilentlyContinue) {
            $p = Test-Python $c.Exe $c.Pre
            if ($p) { return $p }
        }
    }
    $local = Get-ChildItem "$env:LOCALAPPDATA\Programs\Python\Python3*\python.exe" -ErrorAction SilentlyContinue |
             Sort-Object FullName -Descending
    foreach ($f in $local) {
        $p = Test-Python $f.FullName @()
        if ($p) { return $p }
    }
    return $null
}

function Install-Python {
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        Write-Host "  Installation de Python $PyMinor avec winget (1 à 3 minutes)..."
        $code = Invoke-Native 'winget' @('install', '--id', "Python.Python.$PyMinor", '-e', '--scope', 'user',
                                         '--silent', '--accept-package-agreements', '--accept-source-agreements')
        Update-SessionPath
        $p = Find-Python
        if ($p) { return $p }
        Warn "winget n'a pas abouti (code $code) : téléchargement depuis python.org."
    }
    $index = (Invoke-WebRequest 'https://www.python.org/ftp/python/' -UseBasicParsing).Content
    $versions = [regex]::Matches($index, 'href="(3\.13\.(\d+))/"') |
                ForEach-Object { [pscustomobject]@{ V = $_.Groups[1].Value; N = [int]$_.Groups[2].Value } } |
                Sort-Object N -Descending
    foreach ($v in $versions) {
        # La version la plus récente n'a pas toujours d'installateur Windows : on teste chacune.
        $url = "https://www.python.org/ftp/python/$($v.V)/python-$($v.V)-amd64.exe"
        try { Invoke-WebRequest $url -Method Head -UseBasicParsing | Out-Null } catch { continue }
        $dest = Join-Path $env:TEMP "python-$($v.V)-amd64.exe"
        Write-Host "  Téléchargement de Python $($v.V)..."
        Invoke-WebRequest $url -OutFile $dest -UseBasicParsing
        Write-Host '  Installation silencieuse (sans droits administrateur)...'
        Start-Process -FilePath $dest -Wait -ArgumentList @(
            '/quiet', 'InstallAllUsers=0', 'PrependPath=1', 'Include_launcher=1',
            'InstallLauncherAllUsers=0', 'Include_test=0')
        Remove-Item $dest -ErrorAction SilentlyContinue
        Update-SessionPath
        return Find-Python
    }
    return $null
}

function New-Shortcut([string]$Path, [string]$Target, [string]$Arguments, [string]$WorkDir,
                      [string]$Icon, [string]$Description) {
    $ws = New-Object -ComObject WScript.Shell
    $lnk = $ws.CreateShortcut($Path)
    $lnk.TargetPath = $Target
    $lnk.Arguments = $Arguments
    $lnk.WorkingDirectory = $WorkDir
    if ($Icon) { $lnk.IconLocation = $Icon }
    $lnk.Description = $Description
    $lnk.Save()
}

Write-Host '=====================================================' -ForegroundColor Cyan
Write-Host '   PT Auto - Mise en place automatique'                 -ForegroundColor Cyan
Write-Host '=====================================================' -ForegroundColor Cyan

try {
    # --- 1. Fichiers ---------------------------------------------------------
    Step 1 'Copie des fichiers'
    try { New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null }
    catch {
        $InstallDir = Join-Path $env:LOCALAPPDATA 'PTAuto'
        Warn "C:\ n'est pas accessible en écriture : installation dans $InstallDir"
        New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
    }
    $same = ((Resolve-Path $Source).Path.TrimEnd('\')) -ieq ((Resolve-Path $InstallDir).Path.TrimEnd('\'))
    foreach ($f in $Required + $Optional) {
        $src = Join-Path $Source $f
        if (-not (Test-Path -LiteralPath $src)) {
            if ($Required -contains $f) { throw "Fichier manquant dans $Source : $f (réextrayez l'archive)" }
            continue
        }
        if (-not $same) { Copy-Item -LiteralPath $src -Destination (Join-Path $InstallDir $f) -Force }
    }
    # INSTALLER.bat suit les fichiers, pour pouvoir relancer l'installation depuis le dossier installé
    $bat = $env:PTAUTO_BAT
    $batDest = Join-Path $InstallDir 'INSTALLER.bat'
    if ($bat -and (Test-Path -LiteralPath $bat) -and -not ((Resolve-Path $bat).Path -ieq $batDest)) {
        Copy-Item -LiteralPath $bat -Destination $batDest -Force
    }
    # Ancien installateur (source de confusion avec INSTALLER.bat) : supprimé
    Remove-Item -LiteralPath (Join-Path $InstallDir 'installer.ps1') -Force -ErrorAction SilentlyContinue
    Get-ChildItem -LiteralPath $InstallDir -File | Unblock-File -ErrorAction SilentlyContinue
    Ok "Fichiers en place dans $InstallDir"

    # --- 2. Python -----------------------------------------------------------
    Step 2 'Python'
    $Py = Find-Python
    if ($Py) { Ok "Python déjà installé : $Py" }
    else {
        $Py = Install-Python
        if (-not $Py) { throw "Impossible d'installer Python. Installez Python $PyMinor depuis python.org puis relancez." }
        Ok "Python installé : $Py"
    }

    # --- 3. Bibliothèques ----------------------------------------------------
    Step 3 'Bibliothèques Python (première fois : 1 à 2 minutes)'
    if ((Invoke-Native $Py @('-m', 'pip', '--version')) -ne 0) {
        Invoke-Native $Py @('-m', 'ensurepip', '--upgrade') | Out-Null
    }
    $code = Invoke-Native $Py @('-m', 'pip', 'install', '--disable-pip-version-check', '-q',
                                '-r', (Join-Path $InstallDir 'requirements.txt'))
    if ($code -ne 0) { throw "L'installation des bibliothèques a échoué (code $code). Vérifiez la connexion Internet." }
    Ok 'Bibliothèques installées'

    # --- 4. Clé Gemini -------------------------------------------------------
    Step 4 'Clé Gemini'
    $key = [Environment]::GetEnvironmentVariable('GEMINI_API_KEY', 'User')
    if ($key) {
        $end = $key.Substring([Math]::Max(0, $key.Length - 4))
        $ans = Read-Host "  Une clé est déjà enregistrée (se termine par $end). La garder ? (O/n)"
        if ($ans -match '^[nN]') { $key = $null }
    }
    if (-not $key) {
        Write-Host '  Clé à créer ou copier sur https://aistudio.google.com (rubrique « API keys »).'
        $sec = Read-Host '  Collez votre clé Gemini (elle reste invisible) puis Entrée' -AsSecureString
        $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec)
        try { $key = ([Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)).Trim() }
        finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
        if ($key) { [Environment]::SetEnvironmentVariable('GEMINI_API_KEY', $key, 'User') }
    }
    if ($key) {
        $env:GEMINI_API_KEY = $key
        if ((Invoke-Native $Py @((Join-Path $InstallDir 'pt_auto.py'), '--tester-cle')) -eq 0) {
            Ok 'Clé enregistrée et acceptée par Google'
        }
        else { Warn "Clé enregistrée, mais Google l'a refusée (ou pas d'Internet). Relancez l'installateur pour la changer." }
    } else {
        Warn "Aucune clé : la résolution n'utilisera que le plan de secours (très limité)."
    }

    # --- 5. Raccourcis (sans terminal) ---------------------------------------
    Step 5 'Raccourcis de lancement'
    $Pyw = Join-Path (Split-Path -Parent $Py) 'pythonw.exe'
    if (-not (Test-Path -LiteralPath $Pyw)) {
        $c = Get-Command pythonw -ErrorAction SilentlyContinue
        $Pyw = if ($c) { $c.Source } else { $null }
    }
    if (-not $Pyw) { throw "pythonw.exe introuvable à côté de $Py" }
    $ptExe = Get-ChildItem "$env:ProgramFiles\Cisco Packet Tracer*\bin\PacketTracer*.exe" -ErrorAction SilentlyContinue |
             Select-Object -First 1
    $icon = if ($ptExe) { "$($ptExe.FullName),0" } else { "$env:SystemRoot\System32\shell32.dll,238" }
    $script = Join-Path $InstallDir 'pt_auto.py'
    $desktop = [Environment]::GetFolderPath('Desktop')
    New-Shortcut (Join-Path $desktop 'Résoudre TP Packet Tracer.lnk') $Pyw "`"$script`"" $InstallDir $icon `
        "Résout l'activité Packet Tracer ouverte, sans fenêtre de terminal"
    New-Shortcut (Join-Path $desktop 'Aperçu TP Packet Tracer.lnk') $Pyw "`"$script`" --apercu" $InstallDir $icon `
        "Analyse l'activité sans rien modifier"
    $stepScript = Join-Path $InstallDir 'pt_pas_a_pas.py'
    New-Shortcut (Join-Path $desktop 'TP pas à pas Packet Tracer.lnk') $Pyw "`"$stepScript`"" $InstallDir $icon `
        "Résout le TP commande par commande : un clic molette = une commande tapée dans la CLI"
    # Version .bat (même résultat, une fenêtre noire apparaît une fraction de seconde)
    $bat = "@echo off`r`nchcp 65001 >nul`r`nstart `"`" `"$Pyw`" `"$script`" %*`r`n"
    [IO.File]::WriteAllText((Join-Path $InstallDir 'RESOUDRE_TP.bat'), $bat, (New-Object Text.UTF8Encoding $false))
    Ok 'Bureau : « Résoudre TP », « Aperçu TP » et « TP pas à pas » (Packet Tracer)'

    # --- 6. Packet Tracer ----------------------------------------------------
    Step 6 'Packet Tracer (extension cisco-pt-mcp)'
    if ($SansPacketTracer) {
        Warn 'Étape ignorée (-SansPacketTracer).'
    } else {
        Write-Host '  Ne touchez pas à la souris pendant cette étape, sauf si on vous le demande.'
        $old = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        & $Py (Join-Path $InstallDir 'pt_setup.py')
        $ptCode = $LASTEXITCODE
        $ErrorActionPreference = $old
        if ($ptCode -eq 0) { Ok 'Packet Tracer est prêt' }
        else { Warn "Packet Tracer n'est pas encore relié. Relancez INSTALLER.bat plus tard pour terminer cette étape." }
    }

    Write-Host ''
    Write-Host '=====================================================' -ForegroundColor Green
    Write-Host '   Installation terminée'                               -ForegroundColor Green
    Write-Host '=====================================================' -ForegroundColor Green
    Write-Host '  Pour chaque TP : ouvrez l''activité dans Packet Tracer, puis double-cliquez sur'
    Write-Host '  « Résoudre TP Packet Tracer » sur le Bureau. Un message s''affiche à la fin.'
    Write-Host '  (Vous pouvez aussi glisser le PDF des consignes sur ce raccourci.)'
    Write-Host ''
    Write-Host '  Mode pas à pas : « TP pas à pas Packet Tracer » sur le Bureau. Chaque clic molette'
    Write-Host '  tape UNE commande dans la CLI de l''équipement. Ctrl+F9 : passer, Ctrl+F12 : arrêter.'
    exit 0
}
catch {
    Write-Host ''
    Fail $_.Exception.Message
    exit 1
}
