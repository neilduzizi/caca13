@echo off
rem ==========================================================================
rem  PT Auto - Mise en place. C'est le SEUL fichier a lancer : double-clic.
rem
rem  Le script PowerShell (fichiers\pt_installer.ps1) est charge comme du
rem  texte : le blocage "l'execution de scripts est desactivee sur ce
rem  systeme" ne s'applique donc pas. Aucun droit administrateur requis.
rem ==========================================================================
setlocal
title PT Auto - Installation
set "SRC=%~dp0fichiers"
if not exist "%SRC%\pt_installer.ps1" set "SRC=%~dp0."
if not exist "%SRC%\pt_installer.ps1" goto introuvable
set "PTAUTO_SRC=%SRC%"
set "PTAUTO_BAT=%~f0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$f = Join-Path $env:PTAUTO_SRC 'pt_installer.ps1'; & ([scriptblock]::Create([IO.File]::ReadAllText($f, [Text.Encoding]::UTF8)))"
set "CODE=%ERRORLEVEL%"
echo.
pause
exit /b %CODE%

:introuvable
echo.
echo  ERREUR : le dossier "fichiers" est introuvable a cote de INSTALLER.bat.
echo.
echo  Vous avez sans doute ouvert INSTALLER.bat directement dans l'archive .zip.
echo  Faites : clic droit sur PT_Auto.zip, "Extraire tout...", puis double-cliquez
echo  sur INSTALLER.bat dans le dossier extrait.
echo.
pause
exit /b 1
